package com.example.salescalc.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Одна сделка. Таблица общая для всех категорий, поля категорий nullable —
 * заполняются только для соответствующей категории.
 */
@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,

    // ---- общие поля ----
    val title: String = "",
    val category: String = SaleCategory.IPHONE.name,
    /** Момент покупки (локальная полночь, epoch millis). */
    val purchaseDate: Long = 0L,
    /** Момент продажи (локальная полночь, epoch millis), null — сделка ещё не продана. */
    val saleDate: Long? = null,
    val purchasePrice: Double = 0.0,
    /** null — цена продажи не указана (сделка «в работе»). */
    val salePrice: Double? = null,
    /** Процент комиссии Авито, зафиксированный на момент сделки. */
    val avitoPercent: Double = 5.0,
    val deliveryPacking: Double = 0.0,
    val otherExpenses: Double = 0.0,
    /** Учитывать ли расходы, специфичные для категории. */
    val includeCategoryCosts: Boolean = true,
    /** Черновик — незавершённая сделка, не участвует в статистике. */
    val isDraft: Boolean = false,
    val note: String? = null,

    // ---- iPhone ----
    val iphoneMemory: String? = null,
    /** Battery health, %. */
    val iphoneBatteryHealth: Int? = null,
    val iphoneICloud: String? = null,
    val iphoneScreenState: String? = null,
    val iphoneBatteryReplaced: Boolean? = null,
    val iphoneICloudUnlockCost: Double? = null,

    // ---- Android ----
    val androidBrand: String? = null,
    val androidMemory: String? = null,
    val androidVersion: String? = null,
    val androidGoogleAccount: String? = null,
    val androidScreenReplaceCost: Double? = null,
    val androidBatteryReplaceCost: Double? = null,
    val androidFirmwareCost: Double? = null,

    // ---- Комплектующие ПК ----
    val partType: String? = null,
    val partCondition: String? = null,
    /** Остаток гарантии, мес. */
    val partWarrantyMonths: Int? = null,
    val gpuMiningUsed: Boolean? = null,
    val gpuServiceCost: Double? = null,

    // ---- Сборка ПК ----
    /** Конфигурация кратко: CPU + GPU + RAM + SSD. */
    val buildConfig: String? = null,
    val buildPsu: String? = null,
    val buildAssemblyCost: Double? = null,
    val buildOsCost: Double? = null,
    val buildTestingCost: Double? = null,

    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val saleCategory: SaleCategory get() = SaleCategory.fromKey(category)

    val isInProgress: Boolean get() = isDraft || salePrice == null || saleDate == null

    val status: SaleStatus get() = if (isInProgress) SaleStatus.IN_PROGRESS else SaleStatus.SOLD

    /** Сумма дополнительных расходов по категории. */
    val categoryCosts: Double
        get() {
            if (!includeCategoryCosts) return 0.0
            return when (saleCategory) {
                SaleCategory.IPHONE -> iphoneICloudUnlockCost ?: 0.0
                SaleCategory.ANDROID -> (androidScreenReplaceCost ?: 0.0) +
                        (androidBatteryReplaceCost ?: 0.0) +
                        (androidFirmwareCost ?: 0.0)

                SaleCategory.PC_PARTS ->
                    if (partType == PartType.GPU.name) gpuServiceCost ?: 0.0 else 0.0

                SaleCategory.PC_BUILD -> (buildAssemblyCost ?: 0.0) +
                        (buildOsCost ?: 0.0) +
                        (buildTestingCost ?: 0.0)
            }
        }

    /** Все затраты, не считая комиссии площадки. */
    val invested: Double
        get() = purchasePrice + deliveryPacking + otherExpenses + categoryCosts

    /** Комиссия площадки от цены продажи. */
    val commission: Double
        get() = (salePrice ?: 0.0) * avitoPercent / 100.0

    /** Чистая прибыль (для незавершённых сделок считается по нулям). */
    val profit: Double
        get() = (salePrice ?: 0.0) - invested - commission
}
