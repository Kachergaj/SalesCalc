package com.example.salescalc.ui.history

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.salescalc.R
import com.example.salescalc.data.model.Sale
import com.example.salescalc.data.model.SaleCategory
import com.example.salescalc.data.model.StatusFilter
import com.example.salescalc.ui.common.ChoiceChipRow
import com.example.salescalc.ui.common.ConfirmDialog
import com.example.salescalc.ui.common.DateField
import com.example.salescalc.ui.common.EmptyState
import com.example.salescalc.ui.common.MetricRow
import com.example.salescalc.ui.common.TextInputField
import com.example.salescalc.ui.theme.profitColor
import com.example.salescalc.util.DateUtils
import com.example.salescalc.util.NumberUtils

/**
 * Экран 2 — история сделок: сводка, поиск, фильтры, список карточек,
 * свайп-удаление с подтверждением, тап — редактирование.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    onOpenSale: (Long) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: HistoryViewModel = viewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val currency by viewModel.currencySymbol.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current
    var pendingDelete by remember { mutableStateOf<Sale?>(null) }

    LaunchedEffect(viewModel) {
        viewModel.events.collect {
            snackbarHostState.showSnackbar(context.getString(R.string.deleted))
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.history_title)) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item(key = "summary") { SummaryCard(state, currency) }

            item(key = "search") {
                TextInputField(
                    value = state.filters.query,
                    onValueChange = viewModel::setQuery,
                    label = stringResource(R.string.history_search_hint)
                )
            }

            item(key = "category") {
                ChoiceChipRow(
                    options = listOf<SaleCategory?>(null) + SaleCategory.entries,
                    selected = state.filters.category,
                    labelProvider = { category ->
                        Text(
                            text = if (category == null) {
                                stringResource(R.string.history_filter_all)
                            } else {
                                stringResource(category.titleRes)
                            }
                        )
                    },
                    onSelect = viewModel::setCategory
                )
            }

            item(key = "status") {
                ChoiceChipRow(
                    options = StatusFilter.entries,
                    selected = state.filters.status,
                    labelProvider = { filter ->
                        Text(
                            text = when (filter) {
                                StatusFilter.ALL -> stringResource(R.string.history_filter_all)
                                StatusFilter.SOLD -> stringResource(R.string.status_sold)
                                StatusFilter.IN_PROGRESS -> stringResource(R.string.status_in_progress)
                            }
                        )
                    },
                    onSelect = viewModel::setStatus
                )
            }

            item(key = "dates") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DateField(
                        label = stringResource(R.string.history_date_from),
                        value = state.filters.dateFrom,
                        onDateSelected = viewModel::setDateFrom,
                        allowClear = true,
                        onClear = { viewModel.setDateFrom(null) },
                        modifier = Modifier.weight(1f)
                    )
                    DateField(
                        label = stringResource(R.string.history_date_to),
                        value = state.filters.dateTo,
                        onDateSelected = viewModel::setDateTo,
                        allowClear = true,
                        onClear = { viewModel.setDateTo(null) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item(key = "drafts") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.history_filter_drafts),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f)
                    )
                    androidx.compose.material3.Switch(
                        checked = state.filters.includeDrafts,
                        onCheckedChange = viewModel::setIncludeDrafts
                    )
                }
            }

            item(key = "reset") {
                TextButton(onClick = viewModel::resetFilters) {
                    Text(stringResource(R.string.history_reset_filters))
                }
            }

            if (state.sales.isEmpty()) {
                item(key = "empty") {
                    EmptyState(
                        title = stringResource(R.string.history_empty),
                        subtitle = stringResource(R.string.history_empty_hint)
                    )
                }
            } else {
                items(items = state.sales, key = { it.id }) { sale ->
                    SaleCard(
                        sale = sale,
                        currency = currency,
                        onClick = { onOpenSale(sale.id) },
                        onRequestDelete = { pendingDelete = sale }
                    )
                }
            }
        }
    }

    val saleToDelete = pendingDelete
    if (saleToDelete != null) {
        ConfirmDialog(
            title = stringResource(R.string.delete_confirm_title),
            text = stringResource(R.string.delete_confirm_text, saleToDelete.title),
            onConfirm = {
                viewModel.delete(saleToDelete)
                pendingDelete = null
            },
            onDismiss = { pendingDelete = null }
        )
    }
}

@Composable
private fun SummaryCard(
    state: HistoryUiState,
    currency: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = stringResource(R.string.history_total_profit),
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = NumberUtils.formatSigned(state.totalProfit, currency),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = profitColor(state.totalProfit)
            )
            Spacer(modifier = Modifier.height(8.dp))
            MetricRow(
                label = stringResource(R.string.history_avg_margin),
                value = state.avgMargin?.let { NumberUtils.formatPercent(it) } ?: "—"
            )
            MetricRow(
                label = stringResource(R.string.history_avg_roi),
                value = state.avgRoi?.let { NumberUtils.formatPercent(it) } ?: "—"
            )
            MetricRow(
                label = stringResource(R.string.history_deals_count),
                value = state.dealsCount.toString()
            )
        }
    }
}

@Composable
private fun SaleCard(
    sale: Sale,
    currency: String,
    onClick: () -> Unit,
    onRequestDelete: () -> Unit
) {
    val dismissState = rememberSwipeToDismissBoxState(
        confirmValueChange = { value ->
            if (value != SwipeToDismissBoxValue.Settled) {
                onRequestDelete()
            }
            false
        }
    )

    SwipeToDismissBox(
        state = dismissState,
        enableDismissFromStartToEnd = false,
        enableDismissFromEndToStart = true,
        backgroundContent = {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp),
                contentAlignment = Alignment.CenterEnd
            ) {
                Icon(
                    imageVector = Icons.Filled.Delete,
                    contentDescription = stringResource(R.string.btn_delete),
                    tint = Color.White
                )
            }
        }
    ) {
        Card(
            onClick = onClick,
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.large,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CategoryBadge(sale)
                    Text(
                        text = DateUtils.formatDate(sale.saleDate ?: sale.purchaseDate),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = sale.title,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 2
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (sale.isInProgress) {
                            stringResource(R.string.status_in_progress)
                        } else {
                            NumberUtils.formatSigned(sale.profit, currency)
                        },
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = profitColor(sale.profit, sale.isInProgress)
                    )
                    StatusBadge(sale)
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "${stringResource(R.string.calc_invested)}: " +
                            NumberUtils.formatAmount(sale.invested, currency),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun CategoryBadge(sale: Sale) {
    Card(
        shape = MaterialTheme.shapes.small,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.secondaryContainer
        )
    ) {
        Text(
            text = stringResource(sale.saleCategory.titleRes),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSecondaryContainer,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun StatusBadge(sale: Sale) {
    val inProgress = sale.isInProgress
    Card(
        shape = MaterialTheme.shapes.small,
        colors = CardDefaults.cardColors(
            containerColor = if (inProgress) {
                MaterialTheme.colorScheme.tertiaryContainer
            } else {
                MaterialTheme.colorScheme.primaryContainer
            }
        )
    ) {
        Text(
            text = if (inProgress) {
                stringResource(R.string.status_in_progress)
            } else {
                stringResource(R.string.status_sold)
            },
            style = MaterialTheme.typography.labelMedium,
            color = if (inProgress) {
                MaterialTheme.colorScheme.onTertiaryContainer
            } else {
                MaterialTheme.colorScheme.onPrimaryContainer
            },
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}
