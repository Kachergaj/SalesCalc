package com.example.salescalc.ui.stats

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.salescalc.SalesCalcApp
import com.example.salescalc.data.model.Sale
import com.example.salescalc.data.model.SaleCategory
import com.example.salescalc.data.model.SaleStatus
import com.example.salescalc.data.settings.AppSettings
import com.example.salescalc.domain.SaleMath
import com.example.salescalc.util.DateUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/** Период статистики. */
enum class StatsPeriod {
    WEEK,
    MONTH,
    ALL
}

/** Прибыль по одной категории (для диаграммы). */
data class CategoryProfit(
    val category: SaleCategory,
    val profit: Double
)

data class StatsUiState(
    val period: StatsPeriod = StatsPeriod.WEEK,
    val profit: Double = 0.0,
    val dealsCount: Int = 0,
    val avgProfit: Double = 0.0,
    val avgDays: Double = 0.0,
    val topSales: List<Sale> = emptyList(),
    val categoryProfits: List<CategoryProfit> = emptyList(),
    val stuckCount: Int = 0,
    val stuckSum: Double = 0.0
)

class StatsViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as SalesCalcApp
    private val repository = app.repository
    private val settingsRepository = app.settingsRepository

    private val _period = MutableStateFlow(StatsPeriod.WEEK)
    private val _uiState = MutableStateFlow(StatsUiState())
    val uiState: StateFlow<StatsUiState> = _uiState.asStateFlow()

    private val _currencySymbol = MutableStateFlow(AppSettings.DEFAULT_CURRENCY)
    val currencySymbol: StateFlow<String> = _currencySymbol.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                repository.allSales,
                settingsRepository.settings,
                _period
            ) { sales, settings, period -> Triple(sales, settings, period) }
                .collect { (sales, settings, period) ->
                    _currencySymbol.value = settings.currencySymbol
                    _uiState.value = buildState(sales, settings, period)
                }
        }
    }

    fun setPeriod(period: StatsPeriod) {
        _period.value = period
    }

    private fun buildState(
        all: List<Sale>,
        settings: AppSettings,
        period: StatsPeriod
    ): StatsUiState {
        val today = DateUtils.startOfToday()
        val periodStart = when (period) {
            StatsPeriod.WEEK -> today - 6L * 24L * 60L * 60L * 1000L
            StatsPeriod.MONTH -> today - 29L * 24L * 60L * 60L * 1000L
            StatsPeriod.ALL -> null
        }

        val completed = all.filter { sale ->
            !sale.isDraft &&
                    sale.status == SaleStatus.SOLD &&
                    sale.saleDate != null &&
                    (periodStart == null || sale.saleDate >= periodStart)
        }

        val calculations = completed.map { SaleMath.calculate(it, today) }
        val profit = calculations.sumOf { it.profit }
        val days = calculations.map { it.daysInTurnover.toDouble() }

        val byCategory = SaleCategory.entries.map { category ->
            CategoryProfit(
                category = category,
                profit = completed.filter { it.saleCategory == category }
                    .sumOf { SaleMath.calculate(it, today).profit }
            )
        }

        val top = completed
            .map { it to SaleMath.calculate(it, today).profit }
            .sortedByDescending { it.second }
            .take(3)
            .map { it.first }

        // «Зависшие» — незавершённые сделки старше порога (считаются за всё время).
        val stuck = all.filter { sale ->
            sale.status == SaleStatus.IN_PROGRESS &&
                    DateUtils.daysBetween(sale.purchaseDate, today) > settings.stuckThresholdDays
        }

        return StatsUiState(
            period = period,
            profit = profit,
            dealsCount = completed.size,
            avgProfit = if (completed.isEmpty()) 0.0 else profit / completed.size,
            avgDays = if (days.isEmpty()) 0.0 else days.average(),
            topSales = top,
            categoryProfits = byCategory,
            stuckCount = stuck.size,
            stuckSum = stuck.sumOf { it.invested }
        )
    }
}
