package com.example.salescalc.ui.calculator

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.salescalc.R
import com.example.salescalc.data.model.ICloudState
import com.example.salescalc.data.model.PartCondition
import com.example.salescalc.data.model.PartType
import com.example.salescalc.data.model.SaleCategory
import com.example.salescalc.domain.SaleCalculation
import com.example.salescalc.ui.common.ChoiceChipRow
import com.example.salescalc.ui.common.DateField
import com.example.salescalc.ui.common.MetricRow
import com.example.salescalc.ui.common.NumericField
import com.example.salescalc.ui.common.SectionCard
import com.example.salescalc.ui.common.TextInputField
import com.example.salescalc.ui.theme.profitColor
import com.example.salescalc.util.DateUtils
import com.example.salescalc.util.NumberUtils

/**
 * Экран 1 — калькулятор сделки.
 * Состояние формы хранится в ViewModel (переживает поворот экрана),
 * скролл и локальные флаги — в rememberSaveable.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorScreen(
    saleId: Long,
    onClose: () -> Unit,
    onSaved: () -> Unit = onClose,
    modifier: Modifier = Modifier,
    viewModel: CalculatorViewModel = viewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val currency by viewModel.currencySymbol.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current
    val calculation = state.calculate(DateUtils.startOfToday())

    LaunchedEffect(saleId) { viewModel.load(saleId) }

    LaunchedEffect(viewModel) {
        viewModel.events.collect { event ->
            when (event) {
                is CalculatorEvent.Error ->
                    snackbarHostState.showSnackbar(context.getString(event.messageRes))

                is CalculatorEvent.Saved -> {
                    snackbarHostState.showSnackbar(
                        context.getString(
                            if (event.isDraft) R.string.draft_saved else R.string.saved_ok
                        )
                    )
                    onSaved()
                }
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        stringResource(
                            if (state.isEditing) R.string.calc_title_edit else R.string.calc_title
                        )
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.btn_cancel)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            CalculatorBottomBar(
                state = state,
                calculation = calculation,
                currency = currency,
                onSave = { viewModel.save(draft = false) },
                onSaveDraft = { viewModel.save(draft = true) },
                onReset = {
                    viewModel.reset()
                    snackbarHostState.currentSnackbarData?.dismiss()
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // ---------------- Категория ----------------
            Text(
                text = stringResource(R.string.calc_category),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))
            ChoiceChipRow(
                options = SaleCategory.entries,
                selected = state.category,
                labelProvider = { Text(stringResource(it.titleRes)) },
                onSelect = viewModel::setCategory
            )

            Spacer(modifier = Modifier.height(16.dp))

            // ---------------- Общие поля ----------------
            SectionCard(title = stringResource(R.string.section_general)) {
                TextInputField(
                    value = state.title,
                    onValueChange = viewModel::setTitle,
                    label = stringResource(R.string.field_title)
                )
                Spacer(modifier = Modifier.height(10.dp))
                DateField(
                    label = stringResource(R.string.field_purchase_date),
                    value = state.purchaseDate,
                    onDateSelected = viewModel::setPurchaseDate
                )
                Spacer(modifier = Modifier.height(10.dp))
                DateField(
                    label = stringResource(R.string.field_sale_date),
                    value = state.saleDate,
                    onDateSelected = viewModel::setSaleDate,
                    allowClear = true,
                    onClear = { viewModel.setSaleDate(null) }
                )
                Spacer(modifier = Modifier.height(10.dp))
                NumericField(
                    value = state.purchasePrice,
                    onValueChange = viewModel::setPurchasePrice,
                    label = stringResource(R.string.field_purchase_price),
                    suffix = currency
                )
                Spacer(modifier = Modifier.height(10.dp))
                NumericField(
                    value = state.salePrice,
                    onValueChange = viewModel::setSalePrice,
                    label = stringResource(R.string.field_sale_price),
                    suffix = currency
                )
                Spacer(modifier = Modifier.height(10.dp))
                NumericField(
                    value = state.avitoPercent,
                    onValueChange = viewModel::setAvitoPercent,
                    label = stringResource(R.string.field_avito_percent),
                    suffix = stringResource(R.string.unit_percent)
                )
                Spacer(modifier = Modifier.height(10.dp))
                NumericField(
                    value = state.deliveryPacking,
                    onValueChange = viewModel::setDeliveryPacking,
                    label = stringResource(R.string.field_delivery),
                    suffix = currency
                )
                Spacer(modifier = Modifier.height(10.dp))
                NumericField(
                    value = state.otherExpenses,
                    onValueChange = viewModel::setOtherExpenses,
                    label = stringResource(R.string.field_other_expenses),
                    suffix = currency
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // ---------------- Поля категории ----------------
            when (state.category) {
                SaleCategory.IPHONE -> IphoneSection(state, viewModel, currency)
                SaleCategory.ANDROID -> AndroidSection(state, viewModel, currency)
                SaleCategory.PC_PARTS -> PcPartsSection(state, viewModel, currency)
                SaleCategory.PC_BUILD -> PcBuildSection(state, viewModel, currency)
            }

            Spacer(modifier = Modifier.height(16.dp))

            SectionCard(title = stringResource(R.string.field_note)) {
                TextInputField(
                    value = state.note,
                    onValueChange = viewModel::setNote,
                    label = stringResource(R.string.field_note),
                    singleLine = false
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

/** Карточка с живым расчётом + кнопки сохранения (закреплена снизу). */
@Composable
private fun CalculatorBottomBar(
    state: CalculatorUiState,
    calculation: SaleCalculation,
    currency: String,
    onSave: () -> Unit,
    onSaveDraft: () -> Unit,
    onReset: () -> Unit
) {
    Surface(
        tonalElevation = 3.dp,
        color = MaterialTheme.colorScheme.surface
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            ProfitCard(calculation = calculation, currency = currency)
            Spacer(modifier = Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onSave,
                    enabled = state.canSaveAsSale,
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp),
                    shape = MaterialTheme.shapes.medium,
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(
                        horizontal = 8.dp,
                        vertical = 8.dp
                    )
                ) {
                    Text(
                        text = stringResource(R.string.btn_save),
                        fontSize = 13.sp,
                        maxLines = 1,
                        textAlign = TextAlign.Center
                    )
                }
                OutlinedButton(
                    onClick = onSaveDraft,
                    modifier = Modifier
                        .weight(1f)
                        .height(50.dp),
                    shape = MaterialTheme.shapes.medium,
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(
                        horizontal = 8.dp,
                        vertical = 8.dp
                    )
                ) {
                    Text(
                        text = stringResource(R.string.btn_save_draft),
                        fontSize = 13.sp,
                        maxLines = 1,
                        textAlign = TextAlign.Center
                    )
                }
            }
            TextButton(
                onClick = onReset,
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.textButtonColors(
                    contentColor = MaterialTheme.colorScheme.onSurfaceVariant
                )
            ) {
                Text(stringResource(R.string.btn_reset))
            }
        }
    }
}

/** Карточка «живого» пересчёта. */
@Composable
private fun ProfitCard(
    calculation: SaleCalculation,
    currency: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.calc_profit),
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = if (calculation.isInProgress) {
                        stringResource(R.string.calc_in_progress)
                    } else {
                        NumberUtils.formatSigned(calculation.profit, currency)
                    },
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = profitColor(calculation.profit, calculation.isInProgress)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                MiniMetric(
                    label = stringResource(R.string.calc_margin),
                    value = calculation.marginPercent?.let { NumberUtils.formatPercent(it) } ?: "—",
                    modifier = Modifier.weight(1f)
                )
                MiniMetric(
                    label = stringResource(R.string.calc_roi),
                    value = calculation.roiPercent?.let { NumberUtils.formatPercent(it) } ?: "—",
                    modifier = Modifier.weight(1f)
                )
                MiniMetric(
                    label = stringResource(R.string.calc_days),
                    value = calculation.daysInTurnover.toString(),
                    modifier = Modifier.weight(1f)
                )
                MiniMetric(
                    label = stringResource(R.string.calc_profit_per_day),
                    value = if (calculation.isInProgress) "—" else {
                        NumberUtils.formatAmount(calculation.profitPerDay, currency)
                    },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
            Spacer(modifier = Modifier.height(6.dp))

            MetricRow(
                label = stringResource(R.string.calc_invested),
                value = NumberUtils.formatAmount(calculation.invested, currency)
            )
            MetricRow(
                label = stringResource(R.string.calc_commission),
                value = NumberUtils.formatAmount(calculation.commission, currency)
            )
        }
    }
}

@Composable
private fun MiniMetric(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier, horizontalAlignment = Alignment.Start) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium,
            maxLines = 1
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 2
        )
    }
}

// ---------------------------------------------------------------------------
// Динамические секции по категориям
// ---------------------------------------------------------------------------

@Composable
private fun IphoneSection(
    state: CalculatorUiState,
    viewModel: CalculatorViewModel,
    currency: String
) {
    SectionCard(title = stringResource(R.string.section_iphone)) {
        FieldLabel(stringResource(R.string.field_iphone_memory))
        ChoiceChipRow(
            options = MemoryOptions.ALL,
            selected = state.iphoneMemory,
            labelProvider = { Text(stringResource(it.labelRes)) },
            onSelect = { viewModel.setIphoneMemory(it) }
        )

        Spacer(modifier = Modifier.height(12.dp))
        FieldLabel(stringResource(R.string.field_iphone_battery))
        NumericField(
            value = state.iphoneBatteryHealth,
            onValueChange = viewModel::setIphoneBatteryHealth,
            label = stringResource(R.string.field_iphone_battery),
            suffix = stringResource(R.string.unit_percent),
            integerOnly = true
        )

        Spacer(modifier = Modifier.height(12.dp))
        FieldLabel(stringResource(R.string.field_iphone_icloud))
        ChoiceChipRow(
            options = ICloudState.entries,
            selected = state.iphoneICloud,
            labelProvider = { Text(stringResource(it.titleRes)) },
            onSelect = viewModel::setIphoneICloud
        )

        Spacer(modifier = Modifier.height(12.dp))
        FieldLabel(stringResource(R.string.field_iphone_screen))
        ChoiceChipRow(
            options = com.example.salescalc.data.model.ScreenCondition.entries,
            selected = state.iphoneScreenState,
            labelProvider = { Text(stringResource(it.titleRes)) },
            onSelect = viewModel::setIphoneScreenState
        )

        Spacer(modifier = Modifier.height(12.dp))
        FieldLabel(stringResource(R.string.field_iphone_battery_replaced))
        ChoiceChipRow(
            options = listOf(true, false),
            selected = state.iphoneBatteryReplaced,
            labelProvider = {
                Text(stringResource(if (it) R.string.value_yes else R.string.value_no))
            },
            onSelect = viewModel::setIphoneBatteryReplaced
        )

        Spacer(modifier = Modifier.height(12.dp))
        NumericField(
            value = state.iphoneICloudUnlockCost,
            onValueChange = viewModel::setIphoneICloudUnlockCost,
            label = stringResource(R.string.field_iphone_icloud_unlock_cost),
            suffix = currency
        )

        Spacer(modifier = Modifier.height(8.dp))
        IncludeCategoryCostsSwitch(state, viewModel)
    }
}

@Composable
private fun AndroidSection(
    state: CalculatorUiState,
    viewModel: CalculatorViewModel,
    currency: String
) {
    SectionCard(title = stringResource(R.string.section_android)) {
        TextInputField(
            value = state.androidBrand,
            onValueChange = viewModel::setAndroidBrand,
            label = stringResource(R.string.field_android_brand)
        )

        Spacer(modifier = Modifier.height(12.dp))
        FieldLabel(stringResource(R.string.field_android_memory))
        ChoiceChipRow(
            options = MemoryOptions.ALL,
            selected = state.androidMemory,
            labelProvider = { Text(stringResource(it.labelRes)) },
            onSelect = { viewModel.setAndroidMemory(it) }
        )

        Spacer(modifier = Modifier.height(12.dp))
        TextInputField(
            value = state.androidVersion,
            onValueChange = viewModel::setAndroidVersion,
            label = stringResource(R.string.field_android_version)
        )

        Spacer(modifier = Modifier.height(12.dp))
        FieldLabel(stringResource(R.string.field_android_google))
        ChoiceChipRow(
            options = com.example.salescalc.data.model.AccountState.entries,
            selected = state.androidGoogleAccount,
            labelProvider = { Text(stringResource(it.titleRes)) },
            onSelect = viewModel::setAndroidGoogleAccount
        )

        Spacer(modifier = Modifier.height(12.dp))
        NumericField(
            value = state.androidScreenReplaceCost,
            onValueChange = viewModel::setAndroidScreenCost,
            label = stringResource(R.string.field_android_screen_cost),
            suffix = currency
        )
        Spacer(modifier = Modifier.height(10.dp))
        NumericField(
            value = state.androidBatteryReplaceCost,
            onValueChange = viewModel::setAndroidBatteryCost,
            label = stringResource(R.string.field_android_battery_cost),
            suffix = currency
        )
        Spacer(modifier = Modifier.height(10.dp))
        NumericField(
            value = state.androidFirmwareCost,
            onValueChange = viewModel::setAndroidFirmwareCost,
            label = stringResource(R.string.field_android_firmware_cost),
            suffix = currency
        )

        Spacer(modifier = Modifier.height(8.dp))
        IncludeCategoryCostsSwitch(state, viewModel)
    }
}

@Composable
private fun PcPartsSection(
    state: CalculatorUiState,
    viewModel: CalculatorViewModel,
    currency: String
) {
    SectionCard(title = stringResource(R.string.section_pc_parts)) {
        PartTypeDropdown(
            value = state.partType,
            onValueChange = viewModel::setPartType
        )

        Spacer(modifier = Modifier.height(12.dp))
        FieldLabel(stringResource(R.string.field_part_condition))
        ChoiceChipRow(
            options = PartCondition.entries,
            selected = state.partCondition,
            labelProvider = { Text(stringResource(it.titleRes)) },
            onSelect = viewModel::setPartCondition
        )

        Spacer(modifier = Modifier.height(12.dp))
        NumericField(
            value = state.partWarrantyMonths,
            onValueChange = viewModel::setPartWarrantyMonths,
            label = stringResource(R.string.field_part_warranty),
            suffix = stringResource(R.string.unit_months),
            integerOnly = true
        )

        if (state.partType == PartType.GPU) {
            Spacer(modifier = Modifier.height(12.dp))
            FieldLabel(stringResource(R.string.field_gpu_mining))
            ChoiceChipRow(
                options = listOf(true, false),
                selected = state.gpuMiningUsed,
                labelProvider = {
                    Text(stringResource(if (it) R.string.value_yes else R.string.value_no))
                },
                onSelect = viewModel::setGpuMiningUsed
            )

            Spacer(modifier = Modifier.height(12.dp))
            NumericField(
                value = state.gpuServiceCost,
                onValueChange = viewModel::setGpuServiceCost,
                label = stringResource(R.string.field_gpu_service),
                suffix = currency
            )
        }

        Spacer(modifier = Modifier.height(8.dp))
        IncludeCategoryCostsSwitch(state, viewModel)
    }
}

@Composable
private fun PcBuildSection(
    state: CalculatorUiState,
    viewModel: CalculatorViewModel,
    currency: String
) {
    SectionCard(title = stringResource(R.string.section_pc_build)) {
        TextInputField(
            value = state.buildConfig,
            onValueChange = viewModel::setBuildConfig,
            label = stringResource(R.string.field_build_config),
            singleLine = false
        )

        Spacer(modifier = Modifier.height(12.dp))
        TextInputField(
            value = state.buildPsu,
            onValueChange = viewModel::setBuildPsu,
            label = stringResource(R.string.field_build_psu),
            keyboardType = KeyboardType.Text
        )

        Spacer(modifier = Modifier.height(12.dp))
        NumericField(
            value = state.buildAssemblyCost,
            onValueChange = viewModel::setBuildAssemblyCost,
            label = stringResource(R.string.field_build_assembly),
            suffix = currency
        )
        Spacer(modifier = Modifier.height(10.dp))
        NumericField(
            value = state.buildOsCost,
            onValueChange = viewModel::setBuildOsCost,
            label = stringResource(R.string.field_build_os),
            suffix = currency
        )
        Spacer(modifier = Modifier.height(10.dp))
        NumericField(
            value = state.buildTestingCost,
            onValueChange = viewModel::setBuildTestingCost,
            label = stringResource(R.string.field_build_testing),
            suffix = currency
        )

        Spacer(modifier = Modifier.height(8.dp))
        IncludeCategoryCostsSwitch(state, viewModel)
    }
}

@Composable
private fun IncludeCategoryCostsSwitch(
    state: CalculatorUiState,
    viewModel: CalculatorViewModel
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = stringResource(R.string.toggle_include_category_costs),
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Switch(
            checked = state.includeCategoryCosts,
            onCheckedChange = viewModel::setIncludeCategoryCosts
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PartTypeDropdown(
    value: PartType,
    onValueChange: (PartType) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = it }
    ) {
        OutlinedTextField(
            value = stringResource(value.titleRes),
            onValueChange = {},
            readOnly = true,
            label = { Text(stringResource(R.string.field_part_type)) },
            trailingIcon = {
                ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
            },
            modifier = Modifier
                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                .fillMaxWidth()
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            PartType.entries.forEach { type ->
                DropdownMenuItem(
                    text = { Text(stringResource(type.titleRes)) },
                    onClick = {
                        onValueChange(type)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
private fun FieldLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Spacer(modifier = Modifier.height(6.dp))
}
