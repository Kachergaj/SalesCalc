package com.example.salescalc.ui.calculator

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.salescalc.SalesCalcApp
import com.example.salescalc.data.model.AccountState
import com.example.salescalc.data.model.ICloudState
import com.example.salescalc.data.model.PartCondition
import com.example.salescalc.data.model.PartType
import com.example.salescalc.data.model.SaleCategory
import com.example.salescalc.data.model.ScreenCondition
import com.example.salescalc.data.settings.AppSettings
import com.example.salescalc.util.DateUtils
import com.example.salescalc.util.NumberUtils
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * ViewModel калькулятора. Состояние формы живёт здесь, поэтому переживает
 * поворот экрана и уход на другой экран (ViewModel привязан к back stack entry).
 */
class CalculatorViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as SalesCalcApp
    private val repository = app.repository
    private val settingsRepository = app.settingsRepository

    private val _uiState = MutableStateFlow(CalculatorUiState())
    val uiState: StateFlow<CalculatorUiState> = _uiState.asStateFlow()

    private val _currencySymbol = MutableStateFlow(AppSettings.DEFAULT_CURRENCY)
    val currencySymbol: StateFlow<String> = _currencySymbol.asStateFlow()

    private val _events = MutableSharedFlow<CalculatorEvent>(extraBufferCapacity = 4)
    val events: SharedFlow<CalculatorEvent> = _events.asSharedFlow()

    private var defaultAvitoPercent = AppSettings.DEFAULT_AVITO_PERCENT
    private var avitoTouched = false
    private var loadedSaleId: Long? = null

    init {
        viewModelScope.launch {
            settingsRepository.settings.collect { settings ->
                _currencySymbol.value = settings.currencySymbol
                defaultAvitoPercent = settings.defaultAvitoPercent
                if (!avitoTouched && !_uiState.value.isEditing) {
                    _uiState.update {
                        it.copy(avitoPercent = NumberUtils.formatPlain(settings.defaultAvitoPercent))
                    }
                }
            }
        }
    }

    /** Загрузка сделки для редактирования (saleId <= 0 — новая сделка). */
    fun load(saleId: Long) {
        if (loadedSaleId == saleId) return
        loadedSaleId = saleId
        avitoTouched = false
        viewModelScope.launch {
            val sale = if (saleId > 0) repository.getById(saleId) else null
            _uiState.value = if (sale != null) {
                CalculatorUiState.fromSale(sale)
            } else {
                newState()
            }
        }
    }

    private fun newState(): CalculatorUiState = CalculatorUiState(
        purchaseDate = DateUtils.startOfToday(),
        saleDate = DateUtils.startOfToday(),
        avitoPercent = NumberUtils.formatPlain(defaultAvitoPercent)
    )

    /** Сброс формы. */
    fun reset() {
        loadedSaleId = null
        avitoTouched = false
        _uiState.value = newState()
    }

    /** Сохранение: draft = true — черновик, иначе завершённая сделка. */
    fun save(draft: Boolean) {
        val state = _uiState.value
        if (state.title.isBlank()) {
            emitError(com.example.salescalc.R.string.error_title_required)
            return
        }
        if (!draft && NumberUtils.parseAmount(state.purchasePrice) <= 0.0) {
            emitError(com.example.salescalc.R.string.error_purchase_price_required)
            return
        }
        if (!draft && !state.canSaveAsSale) {
            emitError(com.example.salescalc.R.string.error_sale_price_required)
            return
        }
        viewModelScope.launch {
            repository.save(state.toSale(draft))
            _events.emit(CalculatorEvent.Saved(isDraft = draft))
        }
    }

    private fun emitError(messageRes: Int) {
        _events.tryEmit(CalculatorEvent.Error(messageRes))
    }

    // ------------------------------------------------------------------
    // Общие поля
    // ------------------------------------------------------------------

    fun setCategory(category: SaleCategory) = _uiState.update { it.copy(category = category) }
    fun setTitle(value: String) = _uiState.update { it.copy(title = value) }
    fun setPurchaseDate(value: Long) = _uiState.update { it.copy(purchaseDate = value) }
    fun setSaleDate(value: Long?) = _uiState.update { it.copy(saleDate = value) }
    fun setPurchasePrice(value: String) = _uiState.update { it.copy(purchasePrice = value) }
    fun setSalePrice(value: String) = _uiState.update { it.copy(salePrice = value) }
    fun setDeliveryPacking(value: String) = _uiState.update { it.copy(deliveryPacking = value) }
    fun setOtherExpenses(value: String) = _uiState.update { it.copy(otherExpenses = value) }
    fun setNote(value: String) = _uiState.update { it.copy(note = value) }

    fun setIncludeCategoryCosts(value: Boolean) =
        _uiState.update { it.copy(includeCategoryCosts = value) }

    fun setAvitoPercent(value: String) {
        avitoTouched = true
        _uiState.update { it.copy(avitoPercent = value) }
    }

    // ------------------------------------------------------------------
    // iPhone
    // ------------------------------------------------------------------

    fun setIphoneMemory(value: MemoryOption) = _uiState.update { it.copy(iphoneMemory = value) }
    fun setIphoneBatteryHealth(value: String) =
        _uiState.update { it.copy(iphoneBatteryHealth = value) }

    fun setIphoneICloud(value: ICloudState) = _uiState.update { it.copy(iphoneICloud = value) }
    fun setIphoneScreenState(value: ScreenCondition) =
        _uiState.update { it.copy(iphoneScreenState = value) }

    fun setIphoneBatteryReplaced(value: Boolean) =
        _uiState.update { it.copy(iphoneBatteryReplaced = value) }

    fun setIphoneICloudUnlockCost(value: String) =
        _uiState.update { it.copy(iphoneICloudUnlockCost = value) }

    // ------------------------------------------------------------------
    // Android
    // ------------------------------------------------------------------

    fun setAndroidBrand(value: String) = _uiState.update { it.copy(androidBrand = value) }
    fun setAndroidMemory(value: MemoryOption) = _uiState.update { it.copy(androidMemory = value) }
    fun setAndroidVersion(value: String) = _uiState.update { it.copy(androidVersion = value) }

    fun setAndroidGoogleAccount(value: AccountState) =
        _uiState.update { it.copy(androidGoogleAccount = value) }

    fun setAndroidScreenCost(value: String) =
        _uiState.update { it.copy(androidScreenReplaceCost = value) }

    fun setAndroidBatteryCost(value: String) =
        _uiState.update { it.copy(androidBatteryReplaceCost = value) }

    fun setAndroidFirmwareCost(value: String) =
        _uiState.update { it.copy(androidFirmwareCost = value) }

    // ------------------------------------------------------------------
    // Комплектующие ПК
    // ------------------------------------------------------------------

    fun setPartType(value: PartType) = _uiState.update { it.copy(partType = value) }
    fun setPartCondition(value: PartCondition) = _uiState.update { it.copy(partCondition = value) }

    fun setPartWarrantyMonths(value: String) =
        _uiState.update { it.copy(partWarrantyMonths = value) }

    fun setGpuMiningUsed(value: Boolean) = _uiState.update { it.copy(gpuMiningUsed = value) }
    fun setGpuServiceCost(value: String) = _uiState.update { it.copy(gpuServiceCost = value) }

    // ------------------------------------------------------------------
    // Сборка ПК
    // ------------------------------------------------------------------

    fun setBuildConfig(value: String) = _uiState.update { it.copy(buildConfig = value) }
    fun setBuildPsu(value: String) = _uiState.update { it.copy(buildPsu = value) }
    fun setBuildAssemblyCost(value: String) =
        _uiState.update { it.copy(buildAssemblyCost = value) }

    fun setBuildOsCost(value: String) = _uiState.update { it.copy(buildOsCost = value) }
    fun setBuildTestingCost(value: String) =
        _uiState.update { it.copy(buildTestingCost = value) }
}
