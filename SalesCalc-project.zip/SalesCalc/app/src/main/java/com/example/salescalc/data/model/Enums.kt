package com.example.salescalc.data.model

import androidx.annotation.StringRes
import com.example.salescalc.R

/**
 * Категория товара. Определяет набор динамических полей в калькуляторе.
 */
enum class SaleCategory(@StringRes val titleRes: Int) {
    IPHONE(R.string.category_iphone),
    ANDROID(R.string.category_android),
    PC_PARTS(R.string.category_pc_parts),
    PC_BUILD(R.string.category_pc_build);

    companion object {
        fun fromKey(key: String?): SaleCategory =
            entries.firstOrNull { it.name == key } ?: IPHONE
    }
}

/** Состояние iCloud на iPhone. */
enum class ICloudState(@StringRes val titleRes: Int) {
    CLEAN(R.string.value_clean),
    LOCKED(R.string.value_locked)
}

/** Состояние экрана iPhone. */
enum class ScreenCondition(@StringRes val titleRes: Int) {
    IDEAL(R.string.screen_ideal),
    SCRATCHES(R.string.screen_scratches),
    CRACK(R.string.screen_crack),
    REPLACED(R.string.screen_replaced)
}

/** Состояние Google-аккаунта на Android. */
enum class AccountState(@StringRes val titleRes: Int) {
    CLEAN(R.string.value_clean),
    LOCKED(R.string.value_locked)
}

/** Тип комплектующей ПК. */
enum class PartType(@StringRes val titleRes: Int) {
    CPU(R.string.part_type_cpu),
    GPU(R.string.part_type_gpu),
    RAM(R.string.part_type_ram),
    SSD(R.string.part_type_ssd),
    HDD(R.string.part_type_hdd),
    MOTHERBOARD(R.string.part_type_motherboard),
    PSU(R.string.part_type_psu),
    COOLER(R.string.part_type_cooler),
    CASE(R.string.part_type_case)
}

/** Состояние комплектующей. */
enum class PartCondition(@StringRes val titleRes: Int) {
    NEW(R.string.condition_new),
    EXCELLENT(R.string.condition_excellent),
    GOOD(R.string.condition_good),
    USED(R.string.condition_used),
    BROKEN(R.string.condition_broken)
}

/** Тема оформления. */
enum class ThemeMode {
    SYSTEM,
    LIGHT,
    DARK
}

/** Статус сделки в истории. */
enum class SaleStatus {
    SOLD,
    IN_PROGRESS
}

/** Фильтр по статусу в истории. */
enum class StatusFilter {
    ALL,
    SOLD,
    IN_PROGRESS
}
