package com.example.salescalc.util

import android.content.Context
import com.example.salescalc.data.model.Sale
import java.io.File
import java.util.Locale

/**
 * Экспорт истории в CSV. Разделитель — «;» и BOM, чтобы файл корректно
 * открывался в Excel и LibreOffice.
 */
object CsvExporter {

    private val SEPARATOR = ";"

    fun export(context: Context, sales: List<Sale>): File {
        val dir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(
            dir,
            "sales_history_${DateUtils.formatFileDate(DateUtils.startOfToday())}.csv"
        )
        file.bufferedWriter(Charsets.UTF_8).use { writer ->
            writer.write('\uFEFF'.code.toChar().toString())
            writer.write(header())
            writer.write("\n")
            sales.forEach { sale ->
                writer.write(row(sale))
                writer.write("\n")
            }
        }
        return file
    }

    private fun header(): String = listOf(
        "Дата покупки",
        "Дата продажи",
        "Категория",
        "Название",
        "Цена покупки",
        "Цена продажи",
        "Комиссия Авито, %",
        "Доставка/упаковка",
        "Прочие расходы",
        "Расходы по категории",
        "Вложено",
        "Комиссия",
        "Прибыль",
        "Маржа, %",
        "ROI, %",
        "Дней в обороте",
        "Статус",
        "Черновик",
        "Примечание",
        "iPhone: память",
        "iPhone: battery health",
        "iPhone: iCloud",
        "iPhone: экран",
        "iPhone: замена АКБ",
        "iPhone: разблокировка iCloud",
        "Android: бренд",
        "Android: память",
        "Android: версия",
        "Android: Google-аккаунт",
        "Android: замена экрана",
        "Android: замена АКБ",
        "Android: прошивка",
        "ПК: тип",
        "ПК: состояние",
        "ПК: гарантия, мес.",
        "ПК: майнинг",
        "ПК: термопаста/обслуживание",
        "Сборка: конфигурация",
        "Сборка: БП",
        "Сборка: сборка/настройка",
        "Сборка: ОС",
        "Сборка: тесты"
    ).joinToString(SEPARATOR)

    private fun row(sale: Sale): String {
        val revenue = sale.salePrice
        val profit = sale.profit
        val margin = if (revenue != null && revenue > 0.0 && !sale.isInProgress) {
            profit / revenue * 100.0
        } else null
        val roi = if (sale.invested > 0.0 && !sale.isInProgress) {
            profit / sale.invested * 100.0
        } else null
        val days = com.example.salescalc.util.DateUtils.daysBetween(
            sale.purchaseDate,
            sale.saleDate ?: sale.purchaseDate
        )

        val cells = listOf(
            DateUtils.formatDate(sale.purchaseDate),
            DateUtils.formatDate(sale.saleDate),
            sale.saleCategory.name,
            sale.title,
            number(sale.purchasePrice),
            revenue?.let { number(it) } ?: "",
            number(sale.avitoPercent),
            number(sale.deliveryPacking),
            number(sale.otherExpenses),
            number(sale.categoryCosts),
            number(sale.invested),
            number(sale.commission),
            number(profit),
            margin?.let { number(it) } ?: "",
            roi?.let { number(it) } ?: "",
            days.toString(),
            if (sale.isInProgress) "В работе" else "Продано",
            if (sale.isDraft) "да" else "нет",
            sale.note.orEmpty(),
            sale.iphoneMemory.orEmpty(),
            sale.iphoneBatteryHealth?.toString() ?: "",
            sale.iphoneICloud.orEmpty(),
            sale.iphoneScreenState.orEmpty(),
            sale.iphoneBatteryReplaced?.let { if (it) "да" else "нет" } ?: "",
            sale.iphoneICloudUnlockCost?.let { number(it) } ?: "",
            sale.androidBrand.orEmpty(),
            sale.androidMemory.orEmpty(),
            sale.androidVersion.orEmpty(),
            sale.androidGoogleAccount.orEmpty(),
            sale.androidScreenReplaceCost?.let { number(it) } ?: "",
            sale.androidBatteryReplaceCost?.let { number(it) } ?: "",
            sale.androidFirmwareCost?.let { number(it) } ?: "",
            sale.partType.orEmpty(),
            sale.partCondition.orEmpty(),
            sale.partWarrantyMonths?.toString() ?: "",
            sale.gpuMiningUsed?.let { if (it) "да" else "нет" } ?: "",
            sale.gpuServiceCost?.let { number(it) } ?: "",
            sale.buildConfig.orEmpty(),
            sale.buildPsu.orEmpty(),
            sale.buildAssemblyCost?.let { number(it) } ?: "",
            sale.buildOsCost?.let { number(it) } ?: "",
            sale.buildTestingCost?.let { number(it) } ?: ""
        )
        return cells.joinToString(SEPARATOR) { escape(it) }
    }

    private fun number(value: Double): String = String.format(Locale.US, "%.2f", value)

    private fun escape(value: String): String = "\"" + value.replace("\"", "\"\"") + "\""
}
