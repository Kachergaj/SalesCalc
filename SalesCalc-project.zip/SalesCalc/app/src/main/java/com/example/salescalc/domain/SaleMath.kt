package com.example.salescalc.domain

import com.example.salescalc.data.model.Sale
import com.example.salescalc.util.DateUtils

/** Результат расчёта по сделке (единая формула для калькулятора, истории и статистики). */
data class SaleCalculation(
    val salePrice: Double = 0.0,
    val commission: Double = 0.0,
    val invested: Double = 0.0,
    val categoryCosts: Double = 0.0,
    val profit: Double = 0.0,
    /** Маржа от цены продажи, %. null — если сделка не завершена. */
    val marginPercent: Double? = null,
    /** ROI на вложенные средства, %. null — если сделка не завершена. */
    val roiPercent: Double? = null,
    val daysInTurnover: Int = 0,
    val isInProgress: Boolean = true,
    val profitPerDay: Double = 0.0
)

/**
 * Формула расчёта:
 *  invested  = цена покупки + доставка/упаковка + прочие расходы + расходы по категории
 *  commission= цена продажи * комиссия Авито / 100
 *  profit    = цена продажи - invested - commission
 *  маржа     = profit / цена продажи * 100
 *  ROI       = profit / invested * 100
 */
object SaleMath {

    fun calculate(
        purchasePrice: Double,
        salePrice: Double?,
        avitoPercent: Double,
        deliveryPacking: Double,
        otherExpenses: Double,
        categoryCosts: Double,
        purchaseDate: Long,
        saleDate: Long?,
        today: Long = DateUtils.startOfToday()
    ): SaleCalculation {
        val invested = purchasePrice + deliveryPacking + otherExpenses + categoryCosts
        val isInProgress = salePrice == null || saleDate == null
        val revenue = salePrice ?: 0.0
        val commission = revenue * avitoPercent / 100.0
        val profit = if (isInProgress) 0.0 else revenue - invested - commission
        val days = DateUtils.daysBetween(purchaseDate, saleDate ?: today).coerceAtLeast(0)

        val margin = if (!isInProgress && revenue > 0.0) profit / revenue * 100.0 else null
        val roi = if (!isInProgress && invested > 0.0) profit / invested * 100.0 else null
        val perDay = if (days > 0) profit / days else profit

        return SaleCalculation(
            salePrice = revenue,
            commission = commission,
            invested = invested,
            categoryCosts = categoryCosts,
            profit = profit,
            marginPercent = margin,
            roiPercent = roi,
            daysInTurnover = days,
            isInProgress = isInProgress,
            profitPerDay = perDay
        )
    }

    /** Пересчёт сохранённой сделки. */
    fun calculate(sale: Sale, today: Long = DateUtils.startOfToday()): SaleCalculation =
        calculate(
            purchasePrice = sale.purchasePrice,
            salePrice = sale.salePrice,
            avitoPercent = sale.avitoPercent,
            deliveryPacking = sale.deliveryPacking,
            otherExpenses = sale.otherExpenses,
            categoryCosts = sale.categoryCosts,
            purchaseDate = sale.purchaseDate,
            saleDate = sale.saleDate,
            today = today
        )
}
