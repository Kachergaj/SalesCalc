package com.example.salescalc.ui.calculator

import androidx.annotation.StringRes
import com.example.salescalc.R
import com.example.salescalc.data.model.AccountState
import com.example.salescalc.data.model.ICloudState
import com.example.salescalc.data.model.PartCondition
import com.example.salescalc.data.model.PartType
import com.example.salescalc.data.model.Sale
import com.example.salescalc.data.model.SaleCategory
import com.example.salescalc.data.model.ScreenCondition
import com.example.salescalc.domain.SaleCalculation
import com.example.salescalc.domain.SaleMath
import com.example.salescalc.util.NumberUtils

/** Вариант памяти: подпись в ресурсах + значение для БД. */
data class MemoryOption(val labelRes: Int, val value: String)

object MemoryOptions {
    val ALL: List<MemoryOption> = listOf(
        MemoryOption(R.string.memory_64, "64"),
        MemoryOption(R.string.memory_128, "128"),
        MemoryOption(R.string.memory_256, "256"),
        MemoryOption(R.string.memory_512, "512"),
        MemoryOption(R.string.memory_1024, "1024")
    )

    val DEFAULT: MemoryOption = MemoryOption(R.string.memory_128, "128")

    fun byValue(value: String?): MemoryOption =
        ALL.firstOrNull { it.value == value } ?: DEFAULT
}

/** Состояние формы калькулятора. Все числовые поля хранятся строками — для маски ввода. */
data class CalculatorUiState(
    val id: Long = 0L,
    val isEditing: Boolean = false,
    val isDraft: Boolean = false,
    val category: SaleCategory = SaleCategory.IPHONE,

    val title: String = "",
    val purchaseDate: Long = 0L,
    val saleDate: Long? = null,
    val purchasePrice: String = "",
    val salePrice: String = "",
    val avitoPercent: String = "5",
    val deliveryPacking: String = "",
    val otherExpenses: String = "",
    val includeCategoryCosts: Boolean = true,
    val note: String = "",

    // iPhone
    val iphoneMemory: MemoryOption = MemoryOptions.DEFAULT,
    val iphoneBatteryHealth: String = "",
    val iphoneICloud: ICloudState = ICloudState.CLEAN,
    val iphoneScreenState: ScreenCondition = ScreenCondition.IDEAL,
    val iphoneBatteryReplaced: Boolean = false,
    val iphoneICloudUnlockCost: String = "",

    // Android
    val androidBrand: String = "",
    val androidMemory: MemoryOption = MemoryOptions.DEFAULT,
    val androidVersion: String = "",
    val androidGoogleAccount: AccountState = AccountState.CLEAN,
    val androidScreenReplaceCost: String = "",
    val androidBatteryReplaceCost: String = "",
    val androidFirmwareCost: String = "",

    // Комплектующие ПК
    val partType: PartType = PartType.CPU,
    val partCondition: PartCondition = PartCondition.EXCELLENT,
    val partWarrantyMonths: String = "",
    val gpuMiningUsed: Boolean = false,
    val gpuServiceCost: String = "",

    // Сборка ПК
    val buildConfig: String = "",
    val buildPsu: String = "",
    val buildAssemblyCost: String = "",
    val buildOsCost: String = "",
    val buildTestingCost: String = "",

    /** Дата создания сделки (сохраняется при редактировании). */
    val createdAt: Long = 0L
) {

    /** Сумма дополнительных расходов по текущей категории. */
    val categoryCosts: Double
        get() {
            if (!includeCategoryCosts) return 0.0
            return when (category) {
                SaleCategory.IPHONE -> NumberUtils.parseAmount(iphoneICloudUnlockCost)
                SaleCategory.ANDROID -> NumberUtils.parseAmount(androidScreenReplaceCost) +
                        NumberUtils.parseAmount(androidBatteryReplaceCost) +
                        NumberUtils.parseAmount(androidFirmwareCost)

                SaleCategory.PC_PARTS ->
                    if (partType == PartType.GPU) NumberUtils.parseAmount(gpuServiceCost) else 0.0

                SaleCategory.PC_BUILD -> NumberUtils.parseAmount(buildAssemblyCost) +
                        NumberUtils.parseAmount(buildOsCost) +
                        NumberUtils.parseAmount(buildTestingCost)
            }
        }

    /** Живой расчёт по текущему состоянию формы. */
    fun calculate(today: Long): SaleCalculation = SaleMath.calculate(
        purchasePrice = NumberUtils.parseAmount(purchasePrice),
        salePrice = if (salePrice.isBlank()) null else NumberUtils.parseAmount(salePrice),
        avitoPercent = NumberUtils.parseAmount(avitoPercent),
        deliveryPacking = NumberUtils.parseAmount(deliveryPacking),
        otherExpenses = NumberUtils.parseAmount(otherExpenses),
        categoryCosts = categoryCosts,
        purchaseDate = purchaseDate,
        saleDate = saleDate,
        today = today
    )

    /** Можно ли сохранить как завершённую сделку. */
    val canSaveAsSale: Boolean
        get() = NumberUtils.parseAmount(salePrice) > 0.0

    /** Сборка entity для сохранения в БД. */
    fun toSale(draft: Boolean): Sale {
        val revenue = if (draft) null else NumberUtils.parseAmount(salePrice).takeIf { it > 0.0 }
        return Sale(
            id = id,
            title = title.trim(),
            category = category.name,
            purchaseDate = purchaseDate,
            saleDate = if (draft) null else saleDate,
            purchasePrice = NumberUtils.parseAmount(purchasePrice),
            salePrice = revenue,
            avitoPercent = NumberUtils.parseAmount(avitoPercent),
            deliveryPacking = NumberUtils.parseAmount(deliveryPacking),
            otherExpenses = NumberUtils.parseAmount(otherExpenses),
            includeCategoryCosts = includeCategoryCosts,
            isDraft = draft,
            note = note.trim().ifBlank { null },

            iphoneMemory = if (category == SaleCategory.IPHONE) iphoneMemory.value else null,
            iphoneBatteryHealth = if (category == SaleCategory.IPHONE) {
                NumberUtils.parseInteger(iphoneBatteryHealth)
            } else null,
            iphoneICloud = if (category == SaleCategory.IPHONE) iphoneICloud.name else null,
            iphoneScreenState = if (category == SaleCategory.IPHONE) iphoneScreenState.name else null,
            iphoneBatteryReplaced = if (category == SaleCategory.IPHONE) iphoneBatteryReplaced else null,
            iphoneICloudUnlockCost = if (category == SaleCategory.IPHONE) {
                NumberUtils.parseAmount(iphoneICloudUnlockCost).takeIf { it > 0.0 }
            } else null,

            androidBrand = if (category == SaleCategory.ANDROID) androidBrand.trim().ifBlank { null } else null,
            androidMemory = if (category == SaleCategory.ANDROID) androidMemory.value else null,
            androidVersion = if (category == SaleCategory.ANDROID) {
                androidVersion.trim().ifBlank { null }
            } else null,
            androidGoogleAccount = if (category == SaleCategory.ANDROID) {
                androidGoogleAccount.name
            } else null,
            androidScreenReplaceCost = if (category == SaleCategory.ANDROID) {
                NumberUtils.parseAmount(androidScreenReplaceCost).takeIf { it > 0.0 }
            } else null,
            androidBatteryReplaceCost = if (category == SaleCategory.ANDROID) {
                NumberUtils.parseAmount(androidBatteryReplaceCost).takeIf { it > 0.0 }
            } else null,
            androidFirmwareCost = if (category == SaleCategory.ANDROID) {
                NumberUtils.parseAmount(androidFirmwareCost).takeIf { it > 0.0 }
            } else null,

            partType = if (category == SaleCategory.PC_PARTS) partType.name else null,
            partCondition = if (category == SaleCategory.PC_PARTS) partCondition.name else null,
            partWarrantyMonths = if (category == SaleCategory.PC_PARTS) {
                NumberUtils.parseInteger(partWarrantyMonths)
            } else null,
            gpuMiningUsed = if (category == SaleCategory.PC_PARTS && partType == PartType.GPU) {
                gpuMiningUsed
            } else null,
            gpuServiceCost = if (category == SaleCategory.PC_PARTS && partType == PartType.GPU) {
                NumberUtils.parseAmount(gpuServiceCost).takeIf { it > 0.0 }
            } else null,

            buildConfig = if (category == SaleCategory.PC_BUILD) buildConfig.trim().ifBlank { null } else null,
            buildPsu = if (category == SaleCategory.PC_BUILD) buildPsu.trim().ifBlank { null } else null,
            buildAssemblyCost = if (category == SaleCategory.PC_BUILD) {
                NumberUtils.parseAmount(buildAssemblyCost).takeIf { it > 0.0 }
            } else null,
            buildOsCost = if (category == SaleCategory.PC_BUILD) {
                NumberUtils.parseAmount(buildOsCost).takeIf { it > 0.0 }
            } else null,
            buildTestingCost = if (category == SaleCategory.PC_BUILD) {
                NumberUtils.parseAmount(buildTestingCost).takeIf { it > 0.0 }
            } else null,

            createdAt = if (id == 0L || createdAt == 0L) System.currentTimeMillis() else createdAt,
            updatedAt = System.currentTimeMillis()
        )
    }

    companion object {
        /** Восстановление состояния формы из сохранённой сделки. */
        fun fromSale(sale: Sale): CalculatorUiState = CalculatorUiState(
            id = sale.id,
            isEditing = sale.id != 0L,
            isDraft = sale.isDraft,
            category = sale.saleCategory,
            title = sale.title,
            purchaseDate = sale.purchaseDate,
            saleDate = sale.saleDate,
            purchasePrice = NumberUtils.formatPlain(sale.purchasePrice),
            salePrice = sale.salePrice?.let { NumberUtils.formatPlain(it) } ?: "",
            avitoPercent = NumberUtils.formatPlain(sale.avitoPercent),
            deliveryPacking = NumberUtils.formatPlain(sale.deliveryPacking),
            otherExpenses = NumberUtils.formatPlain(sale.otherExpenses),
            includeCategoryCosts = sale.includeCategoryCosts,
            note = sale.note.orEmpty(),

            iphoneMemory = MemoryOptions.byValue(sale.iphoneMemory),
            iphoneBatteryHealth = sale.iphoneBatteryHealth?.toString() ?: "",
            iphoneICloud = sale.iphoneICloud.toEnum(ICloudState.CLEAN),
            iphoneScreenState = sale.iphoneScreenState.toEnum(ScreenCondition.IDEAL),
            iphoneBatteryReplaced = sale.iphoneBatteryReplaced ?: false,
            iphoneICloudUnlockCost = sale.iphoneICloudUnlockCost
                ?.let { NumberUtils.formatPlain(it) } ?: "",

            androidBrand = sale.androidBrand.orEmpty(),
            androidMemory = MemoryOptions.byValue(sale.androidMemory),
            androidVersion = sale.androidVersion.orEmpty(),
            androidGoogleAccount = sale.androidGoogleAccount.toEnum(AccountState.CLEAN),
            androidScreenReplaceCost = sale.androidScreenReplaceCost
                ?.let { NumberUtils.formatPlain(it) } ?: "",
            androidBatteryReplaceCost = sale.androidBatteryReplaceCost
                ?.let { NumberUtils.formatPlain(it) } ?: "",
            androidFirmwareCost = sale.androidFirmwareCost
                ?.let { NumberUtils.formatPlain(it) } ?: "",

            partType = sale.partType.toEnum(PartType.CPU),
            partCondition = sale.partCondition.toEnum(PartCondition.EXCELLENT),
            partWarrantyMonths = sale.partWarrantyMonths?.toString() ?: "",
            gpuMiningUsed = sale.gpuMiningUsed ?: false,
            gpuServiceCost = sale.gpuServiceCost?.let { NumberUtils.formatPlain(it) } ?: "",

            buildConfig = sale.buildConfig.orEmpty(),
            buildPsu = sale.buildPsu.orEmpty(),
            buildAssemblyCost = sale.buildAssemblyCost?.let { NumberUtils.formatPlain(it) } ?: "",
            buildOsCost = sale.buildOsCost?.let { NumberUtils.formatPlain(it) } ?: "",
            buildTestingCost = sale.buildTestingCost?.let { NumberUtils.formatPlain(it) } ?: "",

            createdAt = sale.createdAt
        )

        private inline fun <reified T : Enum<T>> String?.toEnum(fallback: T): T =
            this?.let { value -> runCatching { enumValueOf<T>(value) }.getOrNull() } ?: fallback
    }
}

/** События калькулятора для однократного показа сообщений. */
sealed interface CalculatorEvent {
    data class Error(@StringRes val messageRes: Int) : CalculatorEvent
    data class Saved(val isDraft: Boolean) : CalculatorEvent
}
