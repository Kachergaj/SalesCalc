# Калькулятор продаж (SalesCalc)

Офлайн-приложение для перекупа техники: за 10–15 секунд считает чистую прибыль,
маржу, ROI и срок оборота по сделке, сохраняет её в историю и строит статистику.

Полностью офлайн: нет аккаунтов, нет сети, **разрешение INTERNET в манифесте отсутствует**.
Данные лежат в локальной базе Room, настройки — в DataStore.

---

## Стек и версии

| Компонент | Версия |
|---|---|
| Kotlin | 1.9.24 |
| AGP | 8.5.2 |
| Gradle | 8.7 (wrapper) |
| JDK | 17 |
| Compose BOM | 2024.09.02 (Material 3 1.3.0) |
| Compose Compiler | 1.5.14 |
| Room | 2.6.1 (+ KSP 1.9.24-1.0.20) |
| Navigation Compose | 2.8.0 |
| Lifecycle | 2.8.4 (ViewModel + StateFlow) |
| DataStore Preferences | 1.1.1 |
| minSdk / targetSdk / compileSdk | 24 / 34 / 34 |

`package` — `com.example.salescalc` (см. «Смена package name» в конце).

---

## 1. Открыть в Android Studio и собрать debug APK

1. **Android Studio Hedgehog (2023.1.1) или новее** (Ladybug / Narwhal / Otter тоже подойдут).
   Внутри нужен JDK 17 — в Hedgehog+ он встроен (`Settings → Build, Execution, Deployment → Build Tools → Gradle → Gradle JDK = embedded JDK 17`).
2. `File → Open…` → выберите **папку `SalesCalc`** (именно корень проекта, где лежит `settings.gradle.kts`) → `OK`.
   Gradle Sync запустится автоматически.
3. Если IDE не подхватила Wrapper: `File → Settings → Build, Execution, Deployment → Build Tools → Gradle → Gradle distribution = gradle-8.7`.
4. Убедитесь, что установлен **Android SDK Platform 34**:
   `Tools → SDK Manager → SDK Platforms → Android 14 (API 34) → Apply`,
   и `SDK Tools → Android SDK Build-Tools 34.0.0`.
   (Первая синхронизация сама предложит скачать недостающее.)
5. Сборка:
   * **Меню:** `Build → Build Bundle(s) / APK(s) → Build APK(s)`
   * **Терминал в Android Studio или в папке проекта:**
     ```bash
     ./gradlew :app:assembleDebug
     ```
     на Windows — `gradlew.bat :app:assembleDebug`
6. Готовый APK: `app/build/outputs/apk/debug/app-debug.apk`
7. Установка на телефон (по USB, включён «Отладка по USB»):
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```
   Либо просто скопируйте APK на телефон и откройте его (нужно разрешить установку из неизвестных источников).

> Первый запуск требует интернета только для скачивания Gradle-зависимостей.
> Само приложение после установки работает полностью офлайн.

---

## 2. Подписать release APK своим keystore

### 2.1. Создать keystore (один раз)

```bash
keytool -genkeypair -v \
  -keystore ~/salescalc-release.jks \
  -alias salescalc \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -storepass ВАШ_ПАРОЛЬ_ХРАНИЛИЩА \
  -keypass ВАШ_ПАРОЛЬ_КЛЮЧА \
  -dname "CN=SalesCalc, OU=Personal, O=Personal, L=City, S=State, C=RU"
```

### 2.2. Описать keystore в проекте

Создайте в корне проекта файл `keystore.properties` (добавьте его в `.gitignore`, в репозиторий не коммитьте):

```properties
storeFile=/ПОЛНЫЙ/ПУТЬ/К/ВАШЕМУ/ФАЙЛУ/salescalc-release.jks
storePassword=ВАШ_ПАРОЛЬ_ХРАНИЛИЩА
keyAlias=salescalc
keyPassword=ВАШ_ПАРОЛЬ_КЛЮЧА
```

В `app/build.gradle.kts` внесите две правки (файл в комплекте отдаётся без подписи, чтобы проект собирался «из коробки»):

```kotlin
// в самом верху файла, рядом с plugins { ... }
val keystorePropertiesFile = rootProject.file("keystore.properties")
val keystoreProperties = java.util.Properties().apply {
    if (keystorePropertiesFile.exists()) {
        keystorePropertiesFile.inputStream().use { load(it) }
    }
}
```

```kotlin
// внутри android { ... }, рядом с buildTypes
signingConfigs {
    if (keystorePropertiesFile.exists()) {
        create("release") {
            storeFile = file(keystoreProperties["storeFile"] as String)
            storePassword = keystoreProperties["storePassword"] as String
            keyAlias = keystoreProperties["keyAlias"] as String
            keyPassword = keystoreProperties["keyPassword"] as String
        }
    }
}

// и в buildTypes { release { ... } }
signingConfig = signingConfigs.findByName("release")
```

### 2.3. Собрать подписанный APK

```bash
./gradlew :app:assembleRelease
```

Готовый файл: `app/build/outputs/apk/release/app-release.apk` — он уже подписан вашим ключом.

Установка на телефон:

```bash
adb uninstall com.example.salescalc          # debug-версия удалится (подписи разные)
adb install -r app/build/outputs/apk/release/app-release.apk
```

### 2.4. Вариант без правки Gradle-файла (GUI Android Studio)

`Build → Generate Signed Bundle / APK…` → **APK** → `Next` →
` keystore location` (ваш `.jks`), пароли, alias → `Next` → выбрать **release** → `Create` →
готовый подписанный APK: `app/release/app-release.apk`.

---

## 3. Структура проекта

```
SalesCalc/
├── build.gradle.kts                  # корневой скрипт (только alias-плагины)
├── settings.gradle.kts               # репозитории google()/mavenCentral(), модуль :app
├── gradle.properties
├── gradle/
│   ├── libs.versions.toml            # версии всех библиотек (version catalog)
│   └── wrapper/gradle-wrapper.properties
├── gradlew, gradlew.bat              # Gradle Wrapper 8.7
└── app/
    ├── build.gradle.kts               # настройки модуля, зависимости, desugaring
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml        # БЕЗ разрешения INTERNET
        ├── java/com/example/salescalc/
        │   ├── MainActivity.kt
        │   ├── SalesCalcApp.kt        # Application + сервис-локатор зависимостей
        │   ├── data/
        │   │   ├── local/AppDatabase.kt, SaleDao.kt
        │   │   ├── model/Sale.kt (Entity), Enums.kt
        │   │   ├── repository/SaleRepository.kt
        │   │   └── settings/SettingsRepository.kt
        │   ├── domain/SaleMath.kt     # формулы прибыли/маржи/ROI
        │   ├── util/NumberUtils.kt, DateUtils.kt, CsvExporter.kt
        │   └── ui/
        │       ├── calculator/        # Экран 1
        │       ├── history/           # Экран 2
        │       ├── stats/             # Экран 3
        │       ├── settings/          # Экран 4
        │       ├── common/Components.kt
        │       ├── navigation/AppNavHost.kt
        │       └── theme/Color.kt, Theme.kt, Type.kt
        └── res/
            ├── values/strings.xml     # весь русский интерфейс
            ├── values/colors.xml, themes.xml
            ├── values-night/themes.xml
            ├── xml/file_paths.xml, backup_rules.xml, data_extraction_rules.xml
            ├── mipmap-anydpi-v26/    # adaptive icon
            ├── mipmap/                # иконка для Android 7.x
            └── drawable/ic_launcher_foreground.xml
```

---

## 4. Формулы расчёта

```
Вложения        = Цена покупки + Доставка/упаковка + Прочие расходы + Расходы по категории
Комиссия Авито  = Цена продажи × Комиссия, % / 100
Чистая прибыль  = Цена продажи − Вложения − Комиссия
Маржа           = Чистая прибыль / Цена продажи × 100
ROI             = Чистая прибыль / Вложения × 100
Дней в обороте  = Дата продажи − Дата покупки   (если дата продажи пуста — считаем от сегодня)
Прибыль в день  = Чистая прибыль / Дней в обороте
```

Цвет карточки: **зелёный** — прибыль > 0, **красный** — прибыль < 0, **серый** — сделка «в работе».

---

## 5. Логика статусов и черновиков

* **«Сохранить сделку»** доступна только если указана цена продажи (> 0). Иначе кнопка неактивна.
* **«Сохранить как черновик»** работает всегда: сделка сохраняется незавершённой (цена продажи не заполнена).
* В истории незавершённые сделки помечены статусом **«В работе»** и по умолчанию скрыты —
  включить их можно переключателем **«Черновики»** над списком.
* Черновики и сделки «в работе» **не участвуют** в сводке и в статистике (прибыль, маржа, ROI, топ-3).
  Единственное исключение — блок **«Зависшие сделки»** в статистике: там считаются все незавершённые сделки
  старше порога (по умолчанию 14 дней) и сумма «зависших» вложений.
* Тап по карточке в истории открывает редактирование; свайп влево — удаление с подтверждением.

---

## 6. Прочее

* **Числовые поля**: маска ввода (только цифры и один разделитель — запятая или точка),
  отрицательные значения невозможны, длина ограничена 12 цифрами.
* **Состояние калькулятора** живёт в `CalculatorViewModel` (StateFlow) — переживает поворот экрана
  и уход на другие вкладки; локальные флаги — в `rememberSaveable`.
* **Экспорт CSV**: `Настройки → Экспорт истории в CSV` → файл в `cache/exports/` отдаётся
  через `FileProvider` + `Share Intent` (можно отправить в мессенджер, на почту, в Таблицы).
  Разделитель `;`, кодировка UTF-8 с BOM — файл сразу открывается в Excel.
* **Тема**: по умолчанию тёмная; в настройках доступны «Как в системе / Светлая / Тёмная».
* **Смена package name**: `app/build.gradle.kts` (`namespace` и `applicationId`),
  переименовать папку `app/src/main/java/com/example/salescalc` и поправить `package` в 20 файлах
  (в Android Studio: правый клик по пакету → `Refactor → Rename`).

---

## 7. Что нужно для сборки

* JDK 17
* Android SDK Platform 34 + Build-Tools 34.0.0
* Интернет при первом запуске Gradle (для скачивания зависимостей)

---

## 8. Что уже проверено

Проект собран и прогнан на чистой машине (AGP 8.5.2 / Gradle 8.7 / JDK 17 / SDK 34):

* `./gradlew :app:assembleDebug` → **BUILD SUCCESSFUL**, `app-debug.apk` (~18 МБ)
* `./gradlew :app:assembleRelease` → **BUILD SUCCESSFUL**, `app-release-unsigned.apk` (~12 МБ)
  (без `signingConfigs` release-сборка по умолчанию unsigned — подписывается по инструкции из раздела 2)
* `./gradlew :app:testDebugUnitTest` → **5 тестов, 0 падений**
  (`SaleMathTest`: прибыль/маржа/ROI, незавершённая сделка, убыточная сделка, маска чисел, парсер чисел)
* Манифест собранного APK: `package=com.example.salescalc`, `minSdk=24`, `targetSdk=34`,
  launcher-activity `com.example.salescalc.MainActivity`, **разрешения INTERNET нет** —
  в списке только служебное `DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION` от androidx.core.

