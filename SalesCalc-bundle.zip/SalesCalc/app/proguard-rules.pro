# Если включите R8 (isMinifyEnabled = true), оставьте эти правила.
-keepattributes *Annotation*, Signature, InnerClasses, EnclosingMethod

# Room
-keep class * extends androidx.room.RoomDatabase
-dontwarn androidx.room.paging.**

# Kotlin / Compose (на всякий случай)
-dontwarn kotlinx.coroutines.**
