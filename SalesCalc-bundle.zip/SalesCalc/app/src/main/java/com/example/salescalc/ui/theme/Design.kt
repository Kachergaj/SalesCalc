package com.example.salescalc.ui.theme

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DesktopWindows
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PhoneIphone
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.salescalc.data.model.SaleCategory
import com.example.salescalc.data.model.SaleStatus

/** Иконка категории товара. */
fun categoryIcon(category: SaleCategory): ImageVector = when (category) {
    SaleCategory.IPHONE -> Icons.Filled.PhoneIphone
    SaleCategory.ANDROID -> Icons.Filled.Android
    SaleCategory.PC_PARTS -> Icons.Filled.Memory
    SaleCategory.PC_BUILD -> Icons.Filled.DesktopWindows
}

/** Иконка статуса сделки. */
fun statusIcon(status: SaleStatus): ImageVector = when (status) {
    SaleStatus.DRAFT -> Icons.Filled.EditNote
    SaleStatus.IN_PROGRESS -> Icons.Filled.HourglassEmpty
    SaleStatus.SOLD -> Icons.Filled.CheckCircle
}

/** Акцентный цвет категории — используется для плашек, полос и подсветки. */
@Composable
fun categoryAccent(category: SaleCategory): Color {
    val dark = LocalIsDarkTheme.current
    return when (category) {
        SaleCategory.IPHONE -> if (dark) Color(0xFF60A5FA) else Color(0xFF2563EB)
        SaleCategory.ANDROID -> if (dark) Color(0xFF4ADE80) else Color(0xFF15803D)
        SaleCategory.PC_PARTS -> if (dark) Color(0xFFFBBF24) else Color(0xFFB45309)
        SaleCategory.PC_BUILD -> if (dark) Color(0xFFC084FC) else Color(0xFF7E22CE)
    }
}

/** Акцентный цвет статуса сделки. */
@Composable
fun statusAccent(status: SaleStatus): Color {
    val dark = LocalIsDarkTheme.current
    return when (status) {
        SaleStatus.DRAFT -> if (dark) Color(0xFF94A3B8) else Color(0xFF475569)
        SaleStatus.IN_PROGRESS -> if (dark) Color(0xFFFBBF24) else Color(0xFFB45309)
        SaleStatus.SOLD -> if (dark) Color(0xFF4ADE80) else Color(0xFF15803D)
    }
}
