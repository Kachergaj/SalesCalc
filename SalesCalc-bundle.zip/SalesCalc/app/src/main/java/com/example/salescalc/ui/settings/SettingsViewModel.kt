package com.example.salescalc.ui.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.salescalc.SalesCalcApp
import com.example.salescalc.data.model.ThemeMode
import com.example.salescalc.data.settings.AppSettings
import com.example.salescalc.util.CsvExporter
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

sealed interface SettingsEvent {
    data class ExportReady(val file: File) : SettingsEvent
    data object ExportFailed : SettingsEvent
}

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as SalesCalcApp
    private val settingsRepository = app.settingsRepository
    private val repository = app.repository

    private val _uiState = MutableStateFlow(AppSettings())
    val uiState: StateFlow<AppSettings> = _uiState.asStateFlow()

    private val _events = MutableSharedFlow<SettingsEvent>(extraBufferCapacity = 4)
    val events: SharedFlow<SettingsEvent> = _events.asSharedFlow()

    init {
        viewModelScope.launch {
            settingsRepository.settings.collect { settings ->
                _uiState.value = settings
            }
        }
    }

    fun setCurrency(symbol: String) {
        viewModelScope.launch { settingsRepository.setCurrency(symbol) }
    }

    fun setDefaultAvitoPercent(value: Double) {
        viewModelScope.launch { settingsRepository.setDefaultAvitoPercent(value) }
    }

    fun setStuckThresholdDays(value: Int) {
        viewModelScope.launch { settingsRepository.setStuckThresholdDays(value) }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { settingsRepository.setThemeMode(mode) }
    }

    /** Готовит CSV-файл и отдаёт его наружу для отправки через Share Intent. */
    fun exportCsv() {
        viewModelScope.launch {
            try {
                val sales = repository.getAll()
                val file = CsvExporter.export(getApplication(), sales)
                _events.emit(SettingsEvent.ExportReady(file))
            } catch (error: Exception) {
                _events.emit(SettingsEvent.ExportFailed)
            }
        }
    }
}
