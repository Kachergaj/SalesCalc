package com.example.salescalc.ui.history

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.salescalc.SalesCalcApp
import com.example.salescalc.data.model.Sale
import com.example.salescalc.data.model.SaleCategory
import com.example.salescalc.data.model.SaleStatus
import com.example.salescalc.data.model.StatusFilter
import com.example.salescalc.data.settings.AppSettings
import com.example.salescalc.domain.SaleMath
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

/** Фильтры экрана истории. */
data class HistoryFilters(
    val query: String = "",
    val category: SaleCategory? = null,
    val status: StatusFilter = StatusFilter.ALL,
    val dateFrom: Long? = null,
    val dateTo: Long? = null,
    val includeDrafts: Boolean = false
)

/** Состояние экрана истории. */
data class HistoryUiState(
    val sales: List<Sale> = emptyList(),
    val filters: HistoryFilters = HistoryFilters(),
    val totalProfit: Double = 0.0,
    val avgMargin: Double? = null,
    val avgRoi: Double? = null,
    val dealsCount: Int = 0,
    val draftsCount: Int = 0,
    val inProgressCount: Int = 0
)

sealed interface HistoryEvent {
    data object Deleted : HistoryEvent
    data object SaleConfirmed : HistoryEvent
}

class HistoryViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as SalesCalcApp
    private val repository = app.repository
    private val settingsRepository = app.settingsRepository

    private val _uiState = MutableStateFlow(HistoryUiState())
    val uiState: StateFlow<HistoryUiState> = _uiState.asStateFlow()

    private val _currencySymbol = MutableStateFlow(AppSettings.DEFAULT_CURRENCY)
    val currencySymbol: StateFlow<String> = _currencySymbol.asStateFlow()

    private val _events = MutableSharedFlow<HistoryEvent>(extraBufferCapacity = 4)
    val events: SharedFlow<HistoryEvent> = _events.asSharedFlow()

    private val _filters = MutableStateFlow(HistoryFilters())

    init {
        viewModelScope.launch {
            combine(
                repository.allSales,
                settingsRepository.settings,
                _filters
            ) { sales, settings, filters -> Triple(sales, settings.currencySymbol, filters) }
                .collect { (sales, currency, filters) ->
                    _currencySymbol.value = currency
                    _uiState.value = buildState(sales, filters)
                }
        }
    }

    fun setQuery(value: String) = updateFilters { it.copy(query = value) }

    fun setCategory(value: SaleCategory?) = updateFilters { it.copy(category = value) }

    fun setStatus(value: StatusFilter) = updateFilters { it.copy(status = value) }

    fun setDateFrom(value: Long?) = updateFilters { it.copy(dateFrom = value) }

    fun setDateTo(value: Long?) = updateFilters { it.copy(dateTo = value) }

    fun setIncludeDrafts(value: Boolean) = updateFilters { it.copy(includeDrafts = value) }

    fun resetFilters() {
        _filters.value = HistoryFilters()
    }

    fun delete(sale: Sale) {
        viewModelScope.launch {
            repository.delete(sale)
            _events.emit(HistoryEvent.Deleted)
        }
    }

    /**
     * Подтверждение продажи: фиксируем финальную цену и дату,
     * сделка переходит в статус «Продано».
     */
    fun confirmSale(sale: Sale, salePrice: Double, saleDate: Long) {
        viewModelScope.launch {
            repository.save(
                sale.copy(
                    salePrice = salePrice,
                    saleDate = saleDate,
                    status = SaleStatus.SOLD,
                    updatedAt = System.currentTimeMillis()
                )
            )
            _events.emit(HistoryEvent.SaleConfirmed)
        }
    }

    private fun updateFilters(transform: (HistoryFilters) -> HistoryFilters) {
        _filters.value = transform(_filters.value)
    }

    private fun buildState(all: List<Sale>, filters: HistoryFilters): HistoryUiState {
        val filtered = all.filter { sale ->
            val matchesQuery = filters.query.isBlank() ||
                    sale.title.contains(filters.query, ignoreCase = true)
            val matchesCategory =
                filters.category == null || sale.saleCategory == filters.category
            val matchesStatus = when (filters.status) {
                StatusFilter.ALL -> true
                StatusFilter.SOLD -> sale.status == SaleStatus.SOLD
                StatusFilter.IN_PROGRESS -> sale.status == SaleStatus.IN_PROGRESS
            }
            val effectiveDate = sale.saleDate ?: sale.purchaseDate
            val matchesFrom = filters.dateFrom == null || effectiveDate >= filters.dateFrom
            val matchesTo = filters.dateTo == null || effectiveDate <= filters.dateTo
            val matchesDraft = if (sale.status == SaleStatus.DRAFT) filters.includeDrafts else true
            matchesQuery && matchesCategory && matchesStatus && matchesFrom && matchesTo && matchesDraft
        }

        // В сводку попадают только проданные сделки
        val completed = filtered.filter { it.status == SaleStatus.SOLD }
        val calculations = completed.map { SaleMath.calculate(it) }

        val margins = calculations.mapNotNull { it.marginPercent }
        val rois = calculations.mapNotNull { it.roiPercent }

        return HistoryUiState(
            sales = filtered,
            filters = filters,
            totalProfit = calculations.sumOf { it.profit },
            avgMargin = if (margins.isEmpty()) null else margins.average(),
            avgRoi = if (rois.isEmpty()) null else rois.average(),
            dealsCount = completed.size,
            draftsCount = filtered.count { it.status == SaleStatus.DRAFT },
            inProgressCount = filtered.count { it.status == SaleStatus.IN_PROGRESS }
        )
    }
}
