package com.example.salescalc.ui.stats

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.salescalc.R
import com.example.salescalc.data.model.Sale
import com.example.salescalc.ui.common.ChoiceChipRow
import com.example.salescalc.ui.common.EmptyState
import com.example.salescalc.ui.common.MetricRow
import com.example.salescalc.ui.common.SectionCard
import com.example.salescalc.ui.theme.profitColor
import com.example.salescalc.util.DateUtils
import com.example.salescalc.util.NumberUtils
import kotlin.math.abs

/**
 * Экран 3 — статистика: период, ключевые метрики, топ-3 сделок,
 * диаграмма прибыли по категориям (Canvas) и «зависшие» сделки.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatsScreen(
    modifier: Modifier = Modifier,
    viewModel: StatsViewModel = viewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val currency by viewModel.currencySymbol.collectAsStateWithLifecycle()

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.stats_title)) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            ChoiceChipRow(
                options = StatsPeriod.entries,
                selected = state.period,
                labelProvider = { period ->
                    Text(
                        text = when (period) {
                            StatsPeriod.WEEK -> stringResource(R.string.stats_period_week)
                            StatsPeriod.MONTH -> stringResource(R.string.stats_period_month)
                            StatsPeriod.ALL -> stringResource(R.string.stats_period_all)
                        }
                    )
                },
                onSelect = viewModel::setPeriod
            )

            Spacer(modifier = Modifier.height(16.dp))

            SectionCard(title = stringResource(R.string.stats_profit)) {
                Text(
                    text = NumberUtils.formatSigned(state.profit, currency),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = profitColor(state.profit)
                )
                Spacer(modifier = Modifier.height(10.dp))
                MetricRow(
                    label = stringResource(R.string.stats_deals),
                    value = state.dealsCount.toString()
                )
                MetricRow(
                    label = stringResource(R.string.stats_avg_profit),
                    value = NumberUtils.formatAmount(state.avgProfit, currency)
                )
                MetricRow(
                    label = stringResource(R.string.stats_avg_days),
                    value = "${NumberUtils.formatAmount(state.avgDays, "")} ${stringResource(R.string.unit_days_short)}"
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            SectionCard(title = stringResource(R.string.stats_top3)) {
                if (state.topSales.isEmpty()) {
                    EmptyState(title = stringResource(R.string.stats_top_empty))
                } else {
                    state.topSales.forEachIndexed { index, sale ->
                        TopSaleRow(
                            index = index + 1,
                            sale = sale,
                            currency = currency
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            SectionCard(title = stringResource(R.string.stats_by_category)) {
                CategoryProfitChart(
                    data = state.categoryProfits,
                    currency = currency
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            SectionCard(title = stringResource(R.string.stats_stuck)) {
                MetricRow(
                    label = stringResource(R.string.stats_stuck_count),
                    value = state.stuckCount.toString()
                )
                MetricRow(
                    label = stringResource(R.string.stats_stuck_sum),
                    value = NumberUtils.formatAmount(state.stuckSum, currency)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun TopSaleRow(
    index: Int,
    sale: Sale,
    currency: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Card(
            shape = MaterialTheme.shapes.small,
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.secondaryContainer
            )
        ) {
            Text(
                text = index.toString(),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSecondaryContainer,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            )
        }
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 10.dp)
        ) {
            Text(
                text = sale.title,
                style = MaterialTheme.typography.bodyLarge,
                maxLines = 1
            )
            Text(
                text = "${stringResource(sale.saleCategory.titleRes)} · " +
                        DateUtils.formatDate(sale.saleDate),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Text(
            text = NumberUtils.formatSigned(sale.profit, currency),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = profitColor(sale.profit)
        )
    }
}

/** Простая горизонтальная диаграмма прибыли по категориям, нарисованная на Canvas. */
@Composable
private fun CategoryProfitChart(
    data: List<CategoryProfit>,
    currency: String,
    modifier: Modifier = Modifier
) {
    val labels = data.map { stringResource(it.category.titleRes) }
    val values = data.map { NumberUtils.formatSigned(it.profit, currency) }
    val colors: List<Color> = data.map { profitColor(it.profit) }
    val trackColor = MaterialTheme.colorScheme.surfaceVariant
    val labelColor = MaterialTheme.colorScheme.onSurfaceVariant
    val maxAbs = data.maxOfOrNull { abs(it.profit) }?.takeIf { it > 0.0 } ?: 1.0

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height((data.size * 56).dp)
    ) {
        val rowHeight = size.height / data.size.coerceAtLeast(1)
        val labelPaint = android.graphics.Paint().apply {
            isAntiAlias = true
            color = labelColor.toArgb()
            textSize = 13.sp.toPx()
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val valuePaint = android.graphics.Paint().apply {
            isAntiAlias = true
            color = labelColor.toArgb()
            textSize = 13.sp.toPx()
            textAlign = android.graphics.Paint.Align.RIGHT
        }

        data.forEachIndexed { index, item ->
            val rowTop = index * rowHeight
            val labelBaseline = rowTop + 18.sp.toPx()
            val valueWidth = valuePaint.measureText(values[index])
            val barTop = rowTop + 26.sp.toPx()
            val barHeight = 12.sp.toPx()

            drawContext.canvas.nativeCanvas.drawText(
                labels[index],
                0f,
                labelBaseline,
                labelPaint
            )
            drawContext.canvas.nativeCanvas.drawText(
                values[index],
                size.width,
                labelBaseline,
                valuePaint
            )

            val barMaxWidth = size.width - valueWidth - 12.sp.toPx()
            val barWidth = (barMaxWidth * (abs(item.profit) / maxAbs)).toFloat()
            drawRect(
                color = trackColor,
                topLeft = androidx.compose.ui.geometry.Offset(0f, barTop),
                size = androidx.compose.ui.geometry.Size(barMaxWidth, barHeight)
            )
            drawRect(
                color = colors[index],
                topLeft = androidx.compose.ui.geometry.Offset(0f, barTop),
                size = androidx.compose.ui.geometry.Size(barWidth, barHeight)
            )
        }
    }
}
