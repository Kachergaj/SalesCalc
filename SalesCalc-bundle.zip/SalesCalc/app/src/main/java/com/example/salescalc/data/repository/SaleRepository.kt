package com.example.salescalc.data.repository

import com.example.salescalc.data.local.SaleDao
import com.example.salescalc.data.model.Sale
import kotlinx.coroutines.flow.Flow

class SaleRepository(private val dao: SaleDao) {

    val allSales: Flow<List<Sale>> = dao.observeAll()

    val count: Flow<Int> = dao.observeCount()

    suspend fun getAll(): List<Sale> = dao.getAll()

    suspend fun getById(id: Long): Sale? = dao.getById(id)

    /** Возвращает id сохранённой сделки. */
    suspend fun save(sale: Sale): Long =
        if (sale.id == 0L) dao.insert(sale) else {
            dao.update(sale)
            sale.id
        }

    suspend fun delete(sale: Sale) = dao.delete(sale)

    suspend fun deleteById(id: Long) = dao.deleteById(id)
}
