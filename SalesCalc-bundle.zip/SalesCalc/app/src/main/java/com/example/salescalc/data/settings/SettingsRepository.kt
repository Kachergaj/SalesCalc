package com.example.salescalc.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.salescalc.data.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** Настройки приложения, хранятся в DataStore (полностью офлайн). */
data class AppSettings(
    val currencySymbol: String = DEFAULT_CURRENCY,
    val defaultAvitoPercent: Double = DEFAULT_AVITO_PERCENT,
    val stuckThresholdDays: Int = DEFAULT_STUCK_DAYS,
    val themeMode: ThemeMode = ThemeMode.DARK
) {
    companion object {
        const val DEFAULT_CURRENCY = "₽"
        const val DEFAULT_AVITO_PERCENT = 5.0
        const val DEFAULT_STUCK_DAYS = 14
    }
}

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

class SettingsRepository(private val context: Context) {

    val settings: Flow<AppSettings> = context.settingsDataStore.data.map { prefs ->
        AppSettings(
            currencySymbol = prefs[KEY_CURRENCY] ?: AppSettings.DEFAULT_CURRENCY,
            defaultAvitoPercent = prefs[KEY_AVITO] ?: AppSettings.DEFAULT_AVITO_PERCENT,
            stuckThresholdDays = prefs[KEY_STUCK] ?: AppSettings.DEFAULT_STUCK_DAYS,
            themeMode = runCatching {
                ThemeMode.valueOf(prefs[KEY_THEME] ?: ThemeMode.DARK.name)
            }.getOrDefault(ThemeMode.DARK)
        )
    }

    suspend fun setCurrency(symbol: String) {
        context.settingsDataStore.edit { it[KEY_CURRENCY] = symbol }
    }

    suspend fun setDefaultAvitoPercent(value: Double) {
        context.settingsDataStore.edit { it[KEY_AVITO] = value.coerceIn(0.0, 100.0) }
    }

    suspend fun setStuckThresholdDays(value: Int) {
        context.settingsDataStore.edit { it[KEY_STUCK] = value.coerceIn(1, 365) }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.settingsDataStore.edit { it[KEY_THEME] = mode.name }
    }

    private companion object {
        val KEY_CURRENCY = stringPreferencesKey("currency_symbol")
        val KEY_AVITO = doublePreferencesKey("default_avito_percent")
        val KEY_STUCK = intPreferencesKey("stuck_threshold_days")
        val KEY_THEME = stringPreferencesKey("theme_mode")
    }
}
