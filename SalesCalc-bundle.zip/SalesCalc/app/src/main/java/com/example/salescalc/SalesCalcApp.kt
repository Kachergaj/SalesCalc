package com.example.salescalc

import android.app.Application
import com.example.salescalc.data.local.AppDatabase
import com.example.salescalc.data.repository.SaleRepository
import com.example.salescalc.data.settings.SettingsRepository

/** Точка входа приложения, здесь же — простой сервис-локатор зависимостей. */
class SalesCalcApp : Application() {

    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }

    val repository: SaleRepository by lazy { SaleRepository(database.saleDao()) }

    val settingsRepository: SettingsRepository by lazy { SettingsRepository(this) }
}
