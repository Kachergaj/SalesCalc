package com.example.salescalc.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val Default = Typography()

val AppTypography = Typography(
    headlineMedium = Default.headlineMedium.copy(
        fontWeight = FontWeight.Bold,
        fontSize = 26.sp
    ),
    headlineSmall = Default.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
    titleLarge = Default.titleLarge.copy(fontWeight = FontWeight.SemiBold),
    titleMedium = Default.titleMedium.copy(fontWeight = FontWeight.SemiBold),
    bodyLarge = Default.bodyLarge.copy(fontSize = 16.sp),
    bodyMedium = Default.bodyMedium.copy(fontSize = 14.sp),
    labelLarge = Default.labelLarge.copy(fontWeight = FontWeight.SemiBold, fontSize = 14.sp),
    labelSmall = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp
    )
)
