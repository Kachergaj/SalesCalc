package com.example.salescalc.ui.history

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.salescalc.R
import com.example.salescalc.data.model.Sale
import com.example.salescalc.data.model.SaleCategory
import com.example.salescalc.data.model.SaleStatus
import com.example.salescalc.data.model.StatusFilter
import com.example.salescalc.ui.common.ChoiceChipRow
import com.example.salescalc.ui.common.ConfirmDialog
import com.example.salescalc.ui.common.DateField
import com.example.salescalc.ui.common.EmptyState
import com.example.salescalc.ui.common.MetricRow
import com.example.salescalc.ui.common.NumericField
import com.example.salescalc.ui.common.TextInputField
import com.example.salescalc.ui.theme.categoryAccent
import com.example.salescalc.ui.theme.categoryIcon
import com.example.salescalc.ui.theme.profitColor
import com.example.salescalc.ui.theme.statusAccent
import com.example.salescalc.ui.theme.statusIcon
import com.example.salescalc.util.DateUtils
import com.example.salescalc.util.NumberUtils

/**
 * Экран 2 — история сделок: сводка, поиск, фильтры, карточки с цветной полосой категории,
 * свайп-удаление с подтверждением, тап — редактирование,
 * кнопка «Подтвердить продажу» для сделок в работе.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    onOpenSale: (Long) -> Unit,
    modifier: Modifier = Modifier,
    viewModel: HistoryViewModel = viewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val currency by viewModel.currencySymbol.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current
    var pendingDelete by remember { mutableStateOf<Sale?>(null) }
    var saleToConfirm by remember { mutableStateOf<Sale?>(null) }

    LaunchedEffect(viewModel) {
        viewModel.events.collect { event ->
            val message = when (event) {
                HistoryEvent.Deleted -> context.getString(R.string.deleted)
                HistoryEvent.SaleConfirmed -> context.getString(R.string.sale_confirmed)
            }
            snackbarHostState.showSnackbar(message)
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.history_title)) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item(key = "summary") { SummaryCard(state, currency) }

            item(key = "search") {
                TextInputField(
                    value = state.filters.query,
                    onValueChange = viewModel::setQuery,
                    label = stringResource(R.string.history_search_hint)
                )
            }

            item(key = "category") {
                ChoiceChipRow(
                    options = listOf<SaleCategory?>(null) + SaleCategory.entries,
                    selected = state.filters.category,
                    labelProvider = { category ->
                        if (category == null) {
                            Text(stringResource(R.string.history_filter_all))
                        } else {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = categoryIcon(category),
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp),
                                    tint = categoryAccent(category)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(stringResource(category.titleRes))
                            }
                        }
                    },
                    onSelect = viewModel::setCategory
                )
            }

            item(key = "status") {
                ChoiceChipRow(
                    options = StatusFilter.entries,
                    selected = state.filters.status,
                    labelProvider = { filter ->
                        Text(
                            text = when (filter) {
                                StatusFilter.ALL -> stringResource(R.string.history_filter_all)
                                StatusFilter.SOLD -> stringResource(R.string.status_sold)
                                StatusFilter.IN_PROGRESS ->
                                    stringResource(R.string.status_in_progress)
                            }
                        )
                    },
                    onSelect = viewModel::setStatus
                )
            }

            item(key = "dates") {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    DateField(
                        label = stringResource(R.string.history_date_from),
                        value = state.filters.dateFrom,
                        onDateSelected = viewModel::setDateFrom,
                        allowClear = true,
                        onClear = { viewModel.setDateFrom(null) },
                        modifier = Modifier.weight(1f)
                    )
                    DateField(
                        label = stringResource(R.string.history_date_to),
                        value = state.filters.dateTo,
                        onDateSelected = viewModel::setDateTo,
                        allowClear = true,
                        onClear = { viewModel.setDateTo(null) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item(key = "drafts") {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.history_filter_drafts),
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = state.filters.includeDrafts,
                        onCheckedChange = viewModel::setIncludeDrafts
                    )
                }
            }

            item(key = "reset") {
                TextButton(onClick = viewModel::resetFilters) {
                    Text(stringResource(R.string.history_reset_filters))
                }
            }

            if (state.sales.isEmpty()) {
                item(key = "empty") {
                    EmptyState(
                        title = stringResource(R.string.history_empty),
                        subtitle = stringResource(R.string.history_empty_hint)
                    )
                }
            } else {
                items(items = state.sales, key = { it.id }) { sale ->
                    SaleCard(
                        sale = sale,
                        currency = currency,
                        onClick = { onOpenSale(sale.id) },
                        onRequestDelete = { pendingDelete = sale },
                        onConfirmSale = { saleToConfirm = sale }
                    )
                }
            }
        }
    }

    pendingDelete?.let { sale ->
        ConfirmDialog(
            title = stringResource(R.string.delete_confirm_title),
            text = stringResource(R.string.delete_confirm_text, sale.title),
            onConfirm = {
                viewModel.delete(sale)
                pendingDelete = null
            },
            onDismiss = { pendingDelete = null }
        )
    }

    saleToConfirm?.let { sale ->
        ConfirmSaleDialog(
            sale = sale,
            currency = currency,
            onConfirm = { price, date ->
                viewModel.confirmSale(sale, price, date)
                saleToConfirm = null
            },
            onDismiss = { saleToConfirm = null }
        )
    }
}

@Composable
private fun SummaryCard(
    state: HistoryUiState,
    currency: String,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(
                Brush.linearGradient(
                    listOf(
                        MaterialTheme.colorScheme.surfaceVariant,
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                    )
                )
            )
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, shape)
            .padding(16.dp)
    ) {
        Text(
            text = stringResource(R.string.history_total_profit),
            style = MaterialTheme.typography.titleMedium
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = NumberUtils.formatSigned(state.totalProfit, currency),
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = profitColor(state.totalProfit)
        )
        Spacer(modifier = Modifier.height(10.dp))
        MetricRow(
            label = stringResource(R.string.history_avg_margin),
            value = state.avgMargin?.let { NumberUtils.formatPercent(it) } ?: "—"
        )
        MetricRow(
            label = stringResource(R.string.history_avg_roi),
            value = state.avgRoi?.let { NumberUtils.formatPercent(it) } ?: "—"
        )
        MetricRow(
            label = stringResource(R.string.history_deals_count),
            value = state.dealsCount.toString()
        )
        MetricRow(
            label = stringResource(R.string.status_in_progress),
            value = state.inProgressCount.toString()
        )
    }
}

@Composable
private fun SaleCard(
    sale: Sale,
    currency: String,
    onClick: () -> Unit,
    onRequestDelete: () -> Unit,
    onConfirmSale: () -> Unit
) {
    val dismissState = rememberSwipeToDismissBoxState(
        confirmValueChange = { value ->
            if (value != SwipeToDismissBoxValue.Settled) {
                onRequestDelete()
            }
            false
        }
    )
    val accent = categoryAccent(sale.saleCategory)
    val untitled = stringResource(R.string.title_untitled)

    SwipeToDismissBox(
        state = dismissState,
        enableDismissFromStartToEnd = false,
        enableDismissFromEndToStart = true,
        backgroundContent = {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp),
                contentAlignment = Alignment.CenterEnd
            ) {
                Icon(
                    imageVector = Icons.Filled.Delete,
                    contentDescription = stringResource(R.string.btn_delete),
                    tint = Color.White
                )
            }
        }
    ) {
        Card(
            onClick = onClick,
            modifier = Modifier.fillMaxWidth(),
            shape = MaterialTheme.shapes.large,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Row(modifier = Modifier.height(IntrinsicSize.Min)) {
                // Цветная полоса категории
                Box(
                    modifier = Modifier
                        .width(5.dp)
                        .fillMaxHeight()
                        .background(accent)
                )
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CategoryBadge(sale)
                        Text(
                            text = DateUtils.formatDate(sale.saleDate ?: sale.purchaseDate),
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = sale.title.ifBlank { untitled },
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = when (sale.status) {
                                SaleStatus.SOLD -> NumberUtils.formatSigned(sale.profit, currency)
                                SaleStatus.IN_PROGRESS -> stringResource(R.string.status_in_progress)
                                SaleStatus.DRAFT -> stringResource(R.string.status_draft)
                            },
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = profitColor(sale.profit, sale.status != SaleStatus.SOLD)
                        )
                        StatusBadge(sale.status)
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "${stringResource(R.string.calc_invested)}: " +
                                NumberUtils.formatAmount(sale.invested, currency),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (sale.status == SaleStatus.IN_PROGRESS) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = onConfirmSale,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text(stringResource(R.string.btn_confirm_sale))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CategoryBadge(sale: Sale) {
    val accent = categoryAccent(sale.saleCategory)
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(accent.copy(alpha = 0.16f))
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = categoryIcon(sale.saleCategory),
            contentDescription = null,
            modifier = Modifier.size(14.dp),
            tint = accent
        )
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = stringResource(sale.saleCategory.titleRes),
            style = MaterialTheme.typography.labelMedium,
            color = accent
        )
    }
}

@Composable
private fun StatusBadge(status: SaleStatus) {
    val accent = statusAccent(status)
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(accent.copy(alpha = 0.16f))
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = statusIcon(status),
            contentDescription = null,
            modifier = Modifier.size(14.dp),
            tint = accent
        )
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = stringResource(status.titleRes),
            style = MaterialTheme.typography.labelMedium,
            color = accent
        )
    }
}

/** Диалог подтверждения продажи: финальная цена и дата продажи. */
@Composable
private fun ConfirmSaleDialog(
    sale: Sale,
    currency: String,
    onConfirm: (Double, Long) -> Unit,
    onDismiss: () -> Unit
) {
    var priceInput by rememberSaveable {
        mutableStateOf(sale.salePrice?.let { NumberUtils.formatPlain(it) } ?: "")
    }
    var saleDate by rememberSaveable {
        mutableStateOf(sale.saleDate ?: DateUtils.startOfToday())
    }
    val price = NumberUtils.parseAmount(priceInput)
    val valid = price > 0.0

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.dialog_confirm_sale_title)) },
        text = {
            Column {
                Text(
                    text = stringResource(R.string.dialog_confirm_sale_text),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(14.dp))
                NumericField(
                    value = priceInput,
                    onValueChange = { priceInput = it },
                    label = stringResource(R.string.field_sale_price),
                    suffix = currency,
                    isError = priceInput.isNotEmpty() && !valid
                )
                Spacer(modifier = Modifier.height(10.dp))
                DateField(
                    label = stringResource(R.string.field_sale_date),
                    value = saleDate,
                    onDateSelected = { saleDate = it }
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { onConfirm(price, saleDate) },
                enabled = valid
            ) {
                Text(stringResource(R.string.btn_confirm_sale))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.btn_cancel))
            }
        }
    )
}
