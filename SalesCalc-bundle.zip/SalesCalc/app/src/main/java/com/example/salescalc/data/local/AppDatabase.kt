package com.example.salescalc.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.salescalc.data.model.Sale

@Database(
    entities = [Sale::class],
    version = 2,
    exportSchema = false
)
@TypeConverters(SaleStatusConverter::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun saleDao(): SaleDao

    companion object {
        private const val DB_NAME = "salescalc.db"

        /** v1 → v2: добавлена колонка статуса сделки. */
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "ALTER TABLE sales ADD COLUMN status TEXT NOT NULL DEFAULT 'DRAFT'"
                )
            }
        }

        @Volatile
        private var instance: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    DB_NAME
                )
                    .addMigrations(MIGRATION_1_2)
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { instance = it }
            }
    }
}
