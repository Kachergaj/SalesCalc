package com.example.salescalc.data.local

import androidx.room.TypeConverter
import com.example.salescalc.data.model.SaleStatus

/** Конвертер статуса сделки в строку для Room. */
class SaleStatusConverter {

    @TypeConverter
    fun fromStatus(status: SaleStatus): String = status.name

    @TypeConverter
    fun toStatus(value: String?): SaleStatus = SaleStatus.fromKey(value)
}
