package com.example.salescalc.util

import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

/**
 * Утилиты ввода и форматирования чисел.
 * Поддерживаются и запятая, и точка как десятичный разделитель.
 * Отрицательные значения не допускаются.
 */
object NumberUtils {

    private val ruSymbols = DecimalFormatSymbols(Locale("ru", "RU"))

    const val MAX_DIGITS = 12

    /** Только цифры (для целых полей: гарантия, battery health). */
    fun sanitizeInteger(text: String): String =
        text.filter { it.isDigit() }.take(MAX_DIGITS)

    /**
     * Числовая маска ввода: цифры + не более одного разделителя (запятая или точка),
     * отрицательные значения отбрасываются, длина ограничена.
     */
    fun sanitizeDecimal(text: String, maxDigits: Int = MAX_DIGITS): String {
        val builder = StringBuilder()
        var separatorSeen = false
        var digitCount = 0
        for (ch in text) {
            when {
                ch.isDigit() -> {
                    if (digitCount < maxDigits) {
                        builder.append(ch)
                        digitCount++
                    }
                }

                (ch == ',' || ch == '.') && !separatorSeen && builder.isNotEmpty() -> {
                    separatorSeen = true
                    builder.append(',')
                }
            }
        }
        return builder.toString()
    }

    /** Строка в число. Некорректное значение → 0. */
    fun parseAmount(text: String): Double {
        val normalized = text.trim().replace(',', '.')
        if (normalized.isEmpty()) return 0.0
        val value = normalized.toDoubleOrNull() ?: return 0.0
        if (value.isNaN() || value.isInfinite()) return 0.0
        return value.coerceAtLeast(0.0)
    }

    /** Строка в целое число (null, если строка пустая). */
    fun parseInteger(text: String): Int? {
        val digits = sanitizeInteger(text)
        return if (digits.isEmpty()) null else digits.toIntOrNull()
    }

    /** Форматирование денег: "12 350 ₽". */
    fun formatAmount(value: Double, symbol: String, decimals: Int = 0): String {
        val pattern = if (decimals > 0) "#,##0." + "0".repeat(decimals) else "#,##0"
        val format = DecimalFormat(pattern, ruSymbols)
        format.roundingMode = RoundingMode.HALF_UP
        val number = format.format(value)
        return if (symbol.isBlank()) number else "$number $symbol"
    }

    /** Форматирование процента: "18,4 %". */
    fun formatPercent(value: Double): String {
        val format = DecimalFormat("#0.#", ruSymbols)
        format.roundingMode = RoundingMode.HALF_UP
        return "${format.format(value)} %"
    }

    /** Число без разделителей — для полей ввода: 5.0 -> "5", 5.5 -> "5,5". */
    fun formatPlain(value: Double): String {
        if (value == value.toLong().toDouble()) return value.toLong().toString()
        return value.toString().replace('.', ',')
    }

    /** Знак числа с плюсом для положительных значений: "+1 250 ₽". */
    fun formatSigned(value: Double, symbol: String, decimals: Int = 0): String {
        val sign = if (value > 0) "+" else ""
        return sign + formatAmount(value, symbol, decimals)
    }
}
