package com.example.salescalc.util

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

/** Работа с датами: хранение — локальная полночь в epoch millis, вывод — dd.MM.yyyy. */
object DateUtils {

    private val zone: ZoneId = ZoneId.systemDefault()

    private val dateFormatter: DateTimeFormatter =
        DateTimeFormatter.ofPattern("dd.MM.yyyy", Locale("ru", "RU"))

    private val fileFormatter: DateTimeFormatter =
        DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale("ru", "RU"))

    /** Сегодня в 00:00 локального времени. */
    fun startOfToday(): Long = LocalDate.now(zone).atStartOfDay(zone).toInstant().toEpochMilli()

    fun formatDate(millis: Long?): String {
        if (millis == null) return "—"
        return dateFormatter.format(Instant.ofEpochMilli(millis).atZone(zone).toLocalDate())
    }

    fun formatFileDate(millis: Long?): String {
        if (millis == null) return ""
        return fileFormatter.format(Instant.ofEpochMilli(millis).atZone(zone).toLocalDate())
    }

    /** Количество полных дней между двумя датами. */
    fun daysBetween(from: Long, to: Long): Int {
        val start = Instant.ofEpochMilli(from).atZone(zone).toLocalDate()
        val end = Instant.ofEpochMilli(to).atZone(zone).toLocalDate()
        return ChronoUnit.DAYS.between(start, end).toInt()
    }

    /** Локальная полночь → миллисекунды UTC для Material3 DatePicker. */
    fun toPickerMillis(localMidnight: Long): Long {
        val date = Instant.ofEpochMilli(localMidnight).atZone(zone).toLocalDate()
        return date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
    }

    /** Миллисекунды UTC из DatePicker → локальная полночь. */
    fun fromPickerMillis(pickerMillis: Long): Long {
        val date = Instant.ofEpochMilli(pickerMillis).atZone(ZoneOffset.UTC).toLocalDate()
        return date.atStartOfDay(zone).toInstant().toEpochMilli()
    }
}
