package com.example.salescalc.ui.calculator

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.salescalc.R
import com.example.salescalc.data.model.ICloudState
import com.example.salescalc.data.model.PartCondition
import com.example.salescalc.data.model.PartType
import com.example.salescalc.data.model.SaleCategory
import com.example.salescalc.domain.SaleCalculation
import com.example.salescalc.ui.common.ChoiceChipRow
import com.example.salescalc.ui.common.DateField
import com.example.salescalc.ui.common.MetricRow
import com.example.salescalc.ui.common.NumericField
import com.example.salescalc.ui.common.SectionCard
import com.example.salescalc.ui.common.TextInputField
import com.example.salescalc.ui.theme.categoryAccent
import com.example.salescalc.ui.theme.categoryIcon
import com.example.salescalc.ui.theme.profitColor
import com.example.salescalc.util.DateUtils
import com.example.salescalc.util.NumberUtils

/**
 * Экран 1 — калькулятор сделки.
 *
 * Сверху: выбор категории и сворачиваемый блок с расчётом.
 * Внизу справа: FAB «Сохранить сделку» (галочка).
 * В меню TopAppBar: «Сохранить как черновик» и «Сбросить».
 * Состояние формы хранится в ViewModel (переживает поворот экрана).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorScreen(
    saleId: Long,
    onClose: () -> Unit,
    onSaved: () -> Unit = onClose,
    modifier: Modifier = Modifier,
    viewModel: CalculatorViewModel = viewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val currency by viewModel.currencySymbol.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current
    val calculation = state.calculate(DateUtils.startOfToday())

    var summaryExpanded by rememberSaveable { mutableStateOf(false) }
    var menuExpanded by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(saleId) { viewModel.load(saleId) }

    LaunchedEffect(viewModel) {
        viewModel.events.collect { event ->
            when (event) {
                is CalculatorEvent.Error ->
                    snackbarHostState.showSnackbar(context.getString(event.messageRes))

                is CalculatorEvent.Saved -> {
                    snackbarHostState.showSnackbar(
                        context.getString(
                            if (event.isDraft) R.string.draft_saved else R.string.saved_ok
                        )
                    )
                    onSaved()
                }
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        stringResource(
                            if (state.isEditing) R.string.calc_title_edit else R.string.calc_title
                        )
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onClose) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.btn_cancel)
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { menuExpanded = true }) {
                        Icon(
                            imageVector = Icons.Default.MoreVert,
                            contentDescription = stringResource(R.string.menu_more)
                        )
                    }
                    DropdownMenu(
                        expanded = menuExpanded,
                        onDismissRequest = { menuExpanded = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.btn_save_draft)) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.EditNote,
                                    contentDescription = null
                                )
                            },
                            onClick = {
                                menuExpanded = false
                                viewModel.saveDraft()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.btn_reset)) },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = null
                                )
                            },
                            onClick = {
                                menuExpanded = false
                                viewModel.reset()
                            }
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        floatingActionButton = {
            SaveFab(
                enabled = state.hasValidPurchasePrice,
                onClick = { viewModel.save() }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // ---------------- Категория ----------------
            Text(
                text = stringResource(R.string.calc_category),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))
            ChoiceChipRow(
                options = SaleCategory.entries,
                selected = state.category,
                labelProvider = { category ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = categoryIcon(category),
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                            tint = categoryAccent(category)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(stringResource(category.titleRes))
                    }
                },
                onSelect = viewModel::setCategory
            )

            Spacer(modifier = Modifier.height(14.dp))

            // ---------------- Сворачиваемый блок с расчётом ----------------
            SummaryCard(
                calculation = calculation,
                currency = currency,
                expanded = summaryExpanded,
                onToggle = { summaryExpanded = !summaryExpanded }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // ---------------- Общие поля ----------------
            SectionCard(
                title = stringResource(R.string.section_general),
                accent = categoryAccent(state.category)
            ) {
                TextInputField(
                    value = state.title,
                    onValueChange = viewModel::setTitle,
                    label = stringResource(R.string.field_title)
                )
                Spacer(modifier = Modifier.height(10.dp))
                DateField(
                    label = stringResource(R.string.field_purchase_date),
                    value = state.purchaseDate,
                    onDateSelected = viewModel::setPurchaseDate
                )
                Spacer(modifier = Modifier.height(10.dp))
                DateField(
                    label = stringResource(R.string.field_sale_date),
                    value = state.saleDate,
                    onDateSelected = viewModel::setSaleDate,
                    allowClear = true,
                    onClear = { viewModel.setSaleDate(null) }
                )
                Spacer(modifier = Modifier.height(10.dp))
                NumericField(
                    value = state.purchasePrice,
                    onValueChange = viewModel::setPurchasePrice,
                    label = stringResource(R.string.field_purchase_price),
                    suffix = currency,
                    isError = state.purchasePrice.isNotEmpty() && !state.hasValidPurchasePrice
                )
                Spacer(modifier = Modifier.height(10.dp))
                NumericField(
                    value = state.salePrice,
                    onValueChange = viewModel::setSalePrice,
                    label = stringResource(R.string.field_sale_price),
                    suffix = currency,
                    supportingText = stringResource(R.string.hint_sale_price_optional)
                )
                Spacer(modifier = Modifier.height(10.dp))
                NumericField(
                    value = state.avitoPercent,
                    onValueChange = viewModel::setAvitoPercent,
                    label = stringResource(R.string.field_avito_percent),
                    suffix = stringResource(R.string.unit_percent)
                )
                Spacer(modifier = Modifier.height(10.dp))
                NumericField(
                    value = state.deliveryPacking,
                    onValueChange = viewModel::setDeliveryPacking,
                    label = stringResource(R.string.field_delivery),
                    suffix = currency
                )
                Spacer(modifier = Modifier.height(10.dp))
                NumericField(
                    value = state.otherExpenses,
                    onValueChange = viewModel::setOtherExpenses,
                    label = stringResource(R.string.field_other_expenses),
                    suffix = currency
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // ---------------- Поля категории ----------------
            when (state.category) {
                SaleCategory.IPHONE -> IphoneSection(state, viewModel, currency)
                SaleCategory.ANDROID -> AndroidSection(state, viewModel, currency)
                SaleCategory.PC_PARTS -> PcPartsSection(state, viewModel, currency)
                SaleCategory.PC_BUILD -> PcBuildSection(state, viewModel, currency)
            }

            Spacer(modifier = Modifier.height(16.dp))

            SectionCard(
                title = stringResource(R.string.field_note),
                accent = categoryAccent(state.category)
            ) {
                TextInputField(
                    value = state.note,
                    onValueChange = viewModel::setNote,
                    label = stringResource(R.string.field_note),
                    singleLine = false
                )
            }

            Spacer(modifier = Modifier.height(96.dp))
        }
    }
}

/** FAB «Сохранить сделку». Серая и неактивная, если не заполнена цена покупки. */
@Composable
private fun SaveFab(
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    FloatingActionButton(
        onClick = onClick,
        modifier = modifier.size(62.dp),
        shape = RoundedCornerShape(20.dp),
        containerColor = if (enabled) {
            MaterialTheme.colorScheme.primary
        } else {
            MaterialTheme.colorScheme.surfaceVariant
        },
        contentColor = if (enabled) {
            MaterialTheme.colorScheme.onPrimary
        } else {
            MaterialTheme.colorScheme.onSurfaceVariant
        }
    ) {
        Icon(
            imageVector = Icons.Default.Check,
            contentDescription = stringResource(R.string.btn_save),
            modifier = Modifier.size(30.dp)
        )
    }
}

/**
 * Сворачиваемый блок с расчётом: свёрнут — одна строка «Чистая прибыль: X ₽»,
 * развёрнут — маржа, ROI, дни в обороте, вложения и комиссия.
 */
@Composable
private fun SummaryCard(
    calculation: SaleCalculation,
    currency: String,
    expanded: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = if (calculation.isSold) {
        profitColor(calculation.profit)
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant
    }
    val shape = RoundedCornerShape(22.dp)
    val rotation by animateFloatAsState(
        targetValue = if (expanded) 180f else 0f,
        label = "summary-chevron"
    )

    val profitText = if (calculation.isSold) {
        NumberUtils.formatSigned(calculation.profit, currency)
    } else {
        stringResource(R.string.status_in_progress)
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(shape)
            .background(
                Brush.linearGradient(
                    listOf(
                        MaterialTheme.colorScheme.surfaceVariant,
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                    )
                )
            )
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, shape)
            .clickable(onClick = onToggle)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .background(accent, CircleShape)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "${stringResource(R.string.calc_profit)}: $profitText",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = accent,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Icon(
                imageVector = if (expanded) {
                    Icons.Default.ExpandLess
                } else {
                    Icons.Default.ExpandMore
                },
                contentDescription = stringResource(
                    if (expanded) R.string.calc_collapse else R.string.calc_expand
                ),
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.rotate(rotation)
            )
        }

        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Column {
                Spacer(modifier = Modifier.height(14.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Spacer(modifier = Modifier.height(14.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    MiniMetric(
                        label = stringResource(R.string.calc_margin),
                        value = calculation.marginPercent?.let { NumberUtils.formatPercent(it) } ?: "—",
                        modifier = Modifier.weight(1f)
                    )
                    MiniMetric(
                        label = stringResource(R.string.calc_roi),
                        value = calculation.roiPercent?.let { NumberUtils.formatPercent(it) } ?: "—",
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    MiniMetric(
                        label = stringResource(R.string.calc_days),
                        value = calculation.daysInTurnover.toString(),
                        modifier = Modifier.weight(1f)
                    )
                    MiniMetric(
                        label = stringResource(R.string.calc_profit_per_day),
                        value = if (calculation.isSold) {
                            NumberUtils.formatAmount(calculation.profitPerDay, currency)
                        } else {
                            "—"
                        },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                MetricRow(
                    label = stringResource(R.string.calc_invested),
                    value = NumberUtils.formatAmount(calculation.invested, currency)
                )
                MetricRow(
                    label = stringResource(R.string.calc_commission),
                    value = NumberUtils.formatAmount(calculation.commission, currency)
                )
            }
        }
    }
}

@Composable
private fun MiniMetric(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium,
            maxLines = 1
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 2
        )
    }
}

// ---------------------------------------------------------------------------
// Динамические секции по категориям
// ---------------------------------------------------------------------------

@Composable
private fun IphoneSection(
    state: CalculatorUiState,
    viewModel: CalculatorViewModel,
    currency: String
) {
    SectionCard(
        title = stringResource(R.string.section_iphone),
        accent = categoryAccent(SaleCategory.IPHONE)
    ) {
        FieldLabel(stringResource(R.string.field_iphone_memory))
        ChoiceChipRow(
            options = MemoryOptions.ALL,
            selected = state.iphoneMemory,
            labelProvider = { Text(stringResource(it.labelRes)) },
            onSelect = { viewModel.setIphoneMemory(it) }
        )

        Spacer(modifier = Modifier.height(12.dp))
        FieldLabel(stringResource(R.string.field_iphone_battery))
        NumericField(
            value = state.iphoneBatteryHealth,
            onValueChange = viewModel::setIphoneBatteryHealth,
            label = stringResource(R.string.field_iphone_battery),
            suffix = stringResource(R.string.unit_percent),
            integerOnly = true
        )

        Spacer(modifier = Modifier.height(12.dp))
        FieldLabel(stringResource(R.string.field_iphone_icloud))
        ChoiceChipRow(
            options = ICloudState.entries,
            selected = state.iphoneICloud,
            labelProvider = { Text(stringResource(it.titleRes)) },
            onSelect = viewModel::setIphoneICloud
        )

        Spacer(modifier = Modifier.height(12.dp))
        FieldLabel(stringResource(R.string.field_iphone_screen))
        ChoiceChipRow(
            options = com.example.salescalc.data.model.ScreenCondition.entries,
            selected = state.iphoneScreenState,
            labelProvider = { Text(stringResource(it.titleRes)) },
            onSelect = viewModel::setIphoneScreenState
        )

        Spacer(modifier = Modifier.height(12.dp))
        FieldLabel(stringResource(R.string.field_iphone_battery_replaced))
        ChoiceChipRow(
            options = listOf(true, false),
            selected = state.iphoneBatteryReplaced,
            labelProvider = {
                Text(stringResource(if (it) R.string.value_yes else R.string.value_no))
            },
            onSelect = viewModel::setIphoneBatteryReplaced
        )

        Spacer(modifier = Modifier.height(12.dp))
        NumericField(
            value = state.iphoneICloudUnlockCost,
            onValueChange = viewModel::setIphoneICloudUnlockCost,
            label = stringResource(R.string.field_iphone_icloud_unlock_cost),
            suffix = currency
        )

        Spacer(modifier = Modifier.height(8.dp))
        IncludeCategoryCostsSwitch(state, viewModel)
    }
}

@Composable
private fun AndroidSection(
    state: CalculatorUiState,
    viewModel: CalculatorViewModel,
    currency: String
) {
    SectionCard(
        title = stringResource(R.string.section_android),
        accent = categoryAccent(SaleCategory.ANDROID)
    ) {
        TextInputField(
            value = state.androidBrand,
            onValueChange = viewModel::setAndroidBrand,
            label = stringResource(R.string.field_android_brand)
        )

        Spacer(modifier = Modifier.height(12.dp))
        FieldLabel(stringResource(R.string.field_android_memory))
        ChoiceChipRow(
            options = MemoryOptions.ALL,
            selected = state.androidMemory,
            labelProvider = { Text(stringResource(it.labelRes)) },
            onSelect = { viewModel.setAndroidMemory(it) }
        )

        Spacer(modifier = Modifier.height(12.dp))
        TextInputField(
            value = state.androidVersion,
            onValueChange = { viewModel.setAndroidVersion(it) },
            label = stringResource(R.string.field_android_version)
        )

        Spacer(modifier = Modifier.height(12.dp))
        FieldLabel(stringResource(R.string.field_android_google))
        ChoiceChipRow(
            options = com.example.salescalc.data.model.AccountState.entries,
            selected = state.androidGoogleAccount,
            labelProvider = { Text(stringResource(it.titleRes)) },
            onSelect = viewModel::setAndroidGoogleAccount
        )

        Spacer(modifier = Modifier.height(12.dp))
        NumericField(
            value = state.androidScreenReplaceCost,
            onValueChange = viewModel::setAndroidScreenCost,
            label = stringResource(R.string.field_android_screen_cost),
            suffix = currency
        )
        Spacer(modifier = Modifier.height(10.dp))
        NumericField(
            value = state.androidBatteryReplaceCost,
            onValueChange = viewModel::setAndroidBatteryCost,
            label = stringResource(R.string.field_android_battery_cost),
            suffix = currency
        )
        Spacer(modifier = Modifier.height(10.dp))
        NumericField(
            value = state.androidFirmwareCost,
            onValueChange = viewModel::setAndroidFirmwareCost,
            label = stringResource(R.string.field_android_firmware_cost),
            suffix = currency
        )

        Spacer(modifier = Modifier.height(8.dp))
        IncludeCategoryCostsSwitch(state, viewModel)
    }
}

@Composable
private fun PcPartsSection(
    state: CalculatorUiState,
    viewModel: CalculatorViewModel,
    currency: String
) {
    SectionCard(
        title = stringResource(R.string.section_pc_parts),
        accent = categoryAccent(SaleCategory.PC_PARTS)
    ) {
        PartTypeDropdown(
            value = state.partType,
            onValueChange = viewModel::setPartType
        )

        Spacer(modifier = Modifier.height(12.dp))
        FieldLabel(stringResource(R.string.field_part_condition))
        ChoiceChipRow(
            options = PartCondition.entries,
            selected = state.partCondition,
            labelProvider = { Text(stringResource(it.titleRes)) },
            onSelect = viewModel::setPartCondition
        )

        Spacer(modifier = Modifier.height(12.dp))
        NumericField(
            value = state.partWarrantyMonths,
            onValueChange = viewModel::setPartWarrantyMonths,
            label = stringResource(R.string.field_part_warranty),
            suffix = stringResource(R.string.unit_months),
            integerOnly = true
        )

        if (state.partType == PartType.GPU) {
            Spacer(modifier = Modifier.height(12.dp))
            FieldLabel(stringResource(R.string.field_gpu_mining))
            ChoiceChipRow(
                options = listOf(true, false),
                selected = state.gpuMiningUsed,
                labelProvider = {
                    Text(stringResource(if (it) R.string.value_yes else R.string.value_no))
                },
                onSelect = viewModel::setGpuMiningUsed
            )

            Spacer(modifier = Modifier.height(12.dp))
            NumericField(
                value = state.gpuServiceCost,
                onValueChange = viewModel::setGpuServiceCost,
                label = stringResource(R.string.field_gpu_service),
                suffix = currency
            )
        }

        Spacer(modifier = Modifier.height(8.dp))
        IncludeCategoryCostsSwitch(state, viewModel)
    }
}

@Composable
private fun PcBuildSection(
    state: CalculatorUiState,
    viewModel: CalculatorViewModel,
    currency: String
) {
    SectionCard(
        title = stringResource(R.string.section_pc_build),
        accent = categoryAccent(SaleCategory.PC_BUILD)
    ) {
        TextInputField(
            value = state.buildConfig,
            onValueChange = viewModel::setBuildConfig,
            label = stringResource(R.string.field_build_config),
            singleLine = false
        )

        Spacer(modifier = Modifier.height(12.dp))
        TextInputField(
            value = state.buildPsu,
            onValueChange = { viewModel.setBuildPsu(it) },
            label = stringResource(R.string.field_build_psu),
            keyboardType = KeyboardType.Text
        )

        Spacer(modifier = Modifier.height(12.dp))
        NumericField(
            value = state.buildAssemblyCost,
            onValueChange = { viewModel.setBuildAssemblyCost(it) },
            label = stringResource(R.string.field_build_assembly),
            suffix = currency
        )
        Spacer(modifier = Modifier.height(10.dp))
        NumericField(
            value = state.buildOsCost,
            onValueChange = { viewModel.setBuildOsCost(it) },
            label = stringResource(R.string.field_build_os),
            suffix = currency
        )
        Spacer(modifier = Modifier.height(10.dp))
        NumericField(
            value = state.buildTestingCost,
            onValueChange = { viewModel.setBuildTestingCost(it) },
            label = stringResource(R.string.field_build_testing),
            suffix = currency
        )

        Spacer(modifier = Modifier.height(8.dp))
        IncludeCategoryCostsSwitch(state, viewModel)
    }
}

@Composable
private fun IncludeCategoryCostsSwitch(
    state: CalculatorUiState,
    viewModel: CalculatorViewModel
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = stringResource(R.string.toggle_include_category_costs),
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Switch(
            checked = state.includeCategoryCosts,
            onCheckedChange = viewModel::setIncludeCategoryCosts
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PartTypeDropdown(
    value: PartType,
    onValueChange: (PartType) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = it }
    ) {
        OutlinedTextField(
            value = stringResource(value.titleRes),
            onValueChange = {},
            readOnly = true,
            label = { Text(stringResource(R.string.field_part_type)) },
            leadingIcon = {
                Icon(
                    imageVector = categoryIcon(SaleCategory.PC_PARTS),
                    contentDescription = null
                )
            },
            trailingIcon = {
                ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
            },
            modifier = Modifier
                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                .fillMaxWidth()
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            PartType.entries.forEach { type ->
                DropdownMenuItem(
                    text = { Text(stringResource(type.titleRes)) },
                    onClick = {
                        onValueChange(type)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
private fun FieldLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
    )
    Spacer(modifier = Modifier.height(6.dp))
}
