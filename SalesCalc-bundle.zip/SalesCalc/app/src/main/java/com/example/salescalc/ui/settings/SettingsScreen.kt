package com.example.salescalc.ui.settings

import android.content.Intent
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.salescalc.BuildConfig
import com.example.salescalc.R
import com.example.salescalc.data.model.ThemeMode
import com.example.salescalc.ui.common.ChoiceChipRow
import com.example.salescalc.ui.common.NumericField
import com.example.salescalc.ui.common.SectionCard
import com.example.salescalc.util.NumberUtils

/** Экран 4 — настройки: валюта, комиссия по умолчанию, порог «зависшей» сделки, тема, экспорт CSV. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    modifier: Modifier = Modifier,
    viewModel: SettingsViewModel = viewModel()
) {
    val settings by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val context = LocalContext.current

    var avitoInput by rememberSaveable { mutableStateOf("") }
    var thresholdInput by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(settings.defaultAvitoPercent) {
        if (NumberUtils.parseAmount(avitoInput) != settings.defaultAvitoPercent) {
            avitoInput = NumberUtils.formatPlain(settings.defaultAvitoPercent)
        }
    }
    LaunchedEffect(settings.stuckThresholdDays) {
        if ((thresholdInput.toIntOrNull() ?: -1) != settings.stuckThresholdDays) {
            thresholdInput = settings.stuckThresholdDays.toString()
        }
    }

    LaunchedEffect(viewModel) {
        viewModel.events.collect { event ->
            when (event) {
                is SettingsEvent.ExportReady -> {
                    val uri = FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        event.file
                    )
                    val intent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/csv"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_SUBJECT, event.file.name)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(
                        Intent.createChooser(
                            intent,
                            context.getString(R.string.export_share_title)
                        )
                    )
                }

                SettingsEvent.ExportFailed -> {
                    snackbarHostState.showSnackbar(context.getString(R.string.export_error))
                }
            }
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.settings_title)) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            SectionCard(title = stringResource(R.string.settings_currency)) {
                ChoiceChipRow(
                    options = CURRENCIES,
                    selected = settings.currencySymbol,
                    labelProvider = { Text(it) },
                    onSelect = viewModel::setCurrency
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            SectionCard(title = stringResource(R.string.settings_avito_default)) {
                NumericField(
                    value = avitoInput,
                    onValueChange = { value ->
                        avitoInput = value
                        if (value.isNotBlank()) {
                            viewModel.setDefaultAvitoPercent(NumberUtils.parseAmount(value))
                        }
                    },
                    label = stringResource(R.string.settings_avito_default),
                    suffix = stringResource(R.string.unit_percent)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            SectionCard(title = stringResource(R.string.settings_stuck_threshold)) {
                NumericField(
                    value = thresholdInput,
                    onValueChange = { value ->
                        thresholdInput = value
                        val days = NumberUtils.parseInteger(value)
                        if (days != null) {
                            viewModel.setStuckThresholdDays(days)
                        }
                    },
                    label = stringResource(R.string.settings_stuck_threshold),
                    suffix = stringResource(R.string.unit_days_short),
                    integerOnly = true
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            SectionCard(title = stringResource(R.string.settings_theme)) {
                ChoiceChipRow(
                    options = ThemeMode.entries,
                    selected = settings.themeMode,
                    labelProvider = { mode ->
                        Text(
                            text = when (mode) {
                                ThemeMode.SYSTEM -> stringResource(R.string.theme_system)
                                ThemeMode.LIGHT -> stringResource(R.string.theme_light)
                                ThemeMode.DARK -> stringResource(R.string.theme_dark)
                            }
                        )
                    },
                    onSelect = viewModel::setThemeMode
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            SectionCard(title = stringResource(R.string.settings_export)) {
                Text(
                    text = stringResource(R.string.settings_export_desc),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = viewModel::exportCsv,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Upload,
                        contentDescription = null
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = stringResource(R.string.settings_export),
                        modifier = Modifier.padding(start = 8.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.settings_version),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = BuildConfig.VERSION_NAME,
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

/** Доступные валюты. */
private val CURRENCIES = listOf("₽", "$", "€", "₸", "₴")
