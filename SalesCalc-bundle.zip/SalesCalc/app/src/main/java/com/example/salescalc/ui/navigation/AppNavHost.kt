package com.example.salescalc.ui.navigation

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.salescalc.R
import com.example.salescalc.ui.calculator.CalculatorScreen
import com.example.salescalc.ui.history.HistoryScreen
import com.example.salescalc.ui.settings.SettingsScreen
import com.example.salescalc.ui.stats.StatsScreen

/** Маршруты навигации. */
object Routes {
    const val ARG_SALE_ID = "saleId"
    const val NEW_SALE_ID = -1L

    const val CALCULATOR = "calculator?saleId={saleId}"
    const val HISTORY = "history"
    const val STATS = "stats"
    const val SETTINGS = "settings"

    fun calculator(saleId: Long = NEW_SALE_ID): String = "calculator?saleId=$saleId"
}

private data class BottomItem(
    val route: String,
    val baseRoute: String,
    val icon: ImageVector,
    val labelRes: Int
)

/** Навигация приложения: 4 вкладки в нижней панели (удобно работать одной рукой). */
@Composable
fun AppNavHost(modifier: Modifier = Modifier) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route

    val items = listOf(
        BottomItem(
            route = Routes.calculator(),
            baseRoute = Routes.CALCULATOR,
            icon = Icons.Filled.Calculate,
            labelRes = R.string.nav_calc
        ),
        BottomItem(
            route = Routes.HISTORY,
            baseRoute = Routes.HISTORY,
            icon = Icons.Filled.History,
            labelRes = R.string.nav_history
        ),
        BottomItem(
            route = Routes.STATS,
            baseRoute = Routes.STATS,
            icon = Icons.Filled.Insights,
            labelRes = R.string.nav_stats
        ),
        BottomItem(
            route = Routes.SETTINGS,
            baseRoute = Routes.SETTINGS,
            icon = Icons.Filled.Settings,
            labelRes = R.string.nav_settings
        )
    )

    Scaffold(
        modifier = modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar {
                items.forEach { item ->
                    NavigationBarItem(
                        selected = currentRoute == item.baseRoute,
                        onClick = {
                            if (currentRoute == item.baseRoute) return@NavigationBarItem
                            navController.navigate(item.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = stringResource(item.labelRes)
                            )
                        },
                        label = { Text(stringResource(item.labelRes)) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Routes.calculator(),
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            composable(
                route = Routes.CALCULATOR,
                arguments = listOf(
                    navArgument(Routes.ARG_SALE_ID) {
                        type = NavType.LongType
                        defaultValue = Routes.NEW_SALE_ID
                    }
                )
            ) { entry ->
                val saleId = entry.arguments?.getLong(Routes.ARG_SALE_ID) ?: Routes.NEW_SALE_ID
                CalculatorScreen(
                    saleId = saleId,
                    onClose = { navController.popBackStack() },
                    onSaved = {
                        navController.navigate(Routes.HISTORY) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                )
            }
            composable(route = Routes.HISTORY) {
                HistoryScreen(
                    onOpenSale = { saleId ->
                        navController.navigate(Routes.calculator(saleId))
                    }
                )
            }
            composable(route = Routes.STATS) { StatsScreen() }
            composable(route = Routes.SETTINGS) { SettingsScreen() }
        }
    }
}
