package com.example.salescalc.domain

import com.example.salescalc.data.model.Sale
import com.example.salescalc.data.model.SaleStatus
import com.example.salescalc.util.DateUtils

/** Результат расчёта по сделке (единая формула для калькулятора, истории и статистики). */
data class SaleCalculation(
    val salePrice: Double = 0.0,
    val commission: Double = 0.0,
    val invested: Double = 0.0,
    val categoryCosts: Double = 0.0,
    val profit: Double = 0.0,
    /** Маржа от цены продажи, %. null — если сделка не продана. */
    val marginPercent: Double? = null,
    /** ROI на вложенные средства, %. null — если сделка не продана. */
    val roiPercent: Double? = null,
    val daysInTurnover: Int = 0,
    val status: SaleStatus = SaleStatus.IN_PROGRESS,
    val profitPerDay: Double = 0.0
) {
    /** Прибыль/маржа/ROI считаются только у проданных сделок. */
    val isSold: Boolean get() = status == SaleStatus.SOLD
}

/**
 * Формула расчёта:
 *  invested  = цена покупки + доставка/упаковка + прочие расходы + расходы по категории
 *  commission= цена продажи * комиссия Авито / 100
 *  profit    = цена продажи - invested - commission
 *  маржа     = profit / цена продажи * 100
 *  ROI       = profit / invested * 100
 *
 * Прибыль, маржа и ROI считаются ТОЛЬКО для статуса SOLD.
 * Для IN_PROGRESS и DRAFT маржа и ROI равны null, прибыль не начисляется.
 */
object SaleMath {

    /** Расчёт по сохранённой сделке с учётом её статуса. */
    fun calculate(sale: Sale, today: Long = DateUtils.startOfToday()): SaleCalculation =
        calculate(
            purchasePrice = sale.purchasePrice,
            salePrice = sale.salePrice,
            avitoPercent = sale.avitoPercent,
            deliveryPacking = sale.deliveryPacking,
            otherExpenses = sale.otherExpenses,
            categoryCosts = sale.categoryCosts,
            purchaseDate = sale.purchaseDate,
            saleDate = sale.saleDate,
            status = sale.status,
            today = today
        )

    fun calculate(
        purchasePrice: Double,
        salePrice: Double?,
        avitoPercent: Double,
        deliveryPacking: Double,
        otherExpenses: Double,
        categoryCosts: Double,
        purchaseDate: Long,
        saleDate: Long?,
        status: SaleStatus,
        today: Long = DateUtils.startOfToday()
    ): SaleCalculation {
        val invested = purchasePrice + deliveryPacking + otherExpenses + categoryCosts
        val isSold = status == SaleStatus.SOLD
        val revenue = if (isSold) (salePrice ?: 0.0) else 0.0
        val commission = if (isSold) revenue * avitoPercent / 100.0 else 0.0
        val profit = if (isSold) revenue - invested - commission else 0.0
        val days = DateUtils.daysBetween(purchaseDate, saleDate ?: today).coerceAtLeast(0)

        val margin = if (isSold && revenue > 0.0) profit / revenue * 100.0 else null
        val roi = if (isSold && invested > 0.0) profit / invested * 100.0 else null
        val perDay = if (days > 0) profit / days else profit

        return SaleCalculation(
            salePrice = revenue,
            commission = commission,
            invested = invested,
            categoryCosts = categoryCosts,
            profit = profit,
            marginPercent = margin,
            roiPercent = roi,
            daysInTurnover = days,
            status = status,
            profitPerDay = perDay
        )
    }
}
