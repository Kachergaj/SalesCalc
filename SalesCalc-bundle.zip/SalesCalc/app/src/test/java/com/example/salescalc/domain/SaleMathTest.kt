package com.example.salescalc.domain

import com.example.salescalc.data.model.Sale
import com.example.salescalc.data.model.SaleStatus
import com.example.salescalc.util.DateUtils
import com.example.salescalc.util.NumberUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Проверка формул прибыли, маржи, ROI и маски ввода чисел. */
class SaleMathTest {

    private val day = 24L * 60L * 60L * 1000L

    @Test
    fun calculatesProfitMarginAndRoiForSoldDeal() {
        val today = DateUtils.startOfToday()
        val purchase = today - 5 * day
        val sale = today

        val result = SaleMath.calculate(
            purchasePrice = 40_000.0,
            salePrice = 55_000.0,
            avitoPercent = 5.0,
            deliveryPacking = 1_000.0,
            otherExpenses = 500.0,
            categoryCosts = 2_000.0,
            purchaseDate = purchase,
            saleDate = sale,
            status = SaleStatus.SOLD,
            today = today
        )

        // Вложения = 40 000 + 1 000 + 500 + 2 000
        assertEquals(43_500.0, result.invested, 0.001)
        // Комиссия = 55 000 * 5%
        assertEquals(2_750.0, result.commission, 0.001)
        // Прибыль = 55 000 − 43 500 − 2 750
        assertEquals(8_750.0, result.profit, 0.001)
        // Маржа = 8 750 / 55 000 * 100
        assertEquals(15.909090, result.marginPercent!!, 0.001)
        // ROI = 8 750 / 43 500 * 100
        assertEquals(20.114942, result.roiPercent!!, 0.001)
        assertTrue(result.isSold)
        assertEquals(DateUtils.daysBetween(purchase, sale), result.daysInTurnover)
    }

    @Test
    fun inProgressDealHasNoProfitMarginAndRoi() {
        val today = DateUtils.startOfToday()
        val purchase = today - 3 * day

        val result = SaleMath.calculate(
            purchasePrice = 40_000.0,
            salePrice = 55_000.0,
            avitoPercent = 5.0,
            deliveryPacking = 0.0,
            otherExpenses = 0.0,
            categoryCosts = 0.0,
            purchaseDate = purchase,
            saleDate = today,
            status = SaleStatus.IN_PROGRESS,
            today = today
        )

        assertFalse(result.isSold)
        assertEquals(0.0, result.profit, 0.001)
        assertEquals(0.0, result.commission, 0.001)
        assertNull(result.marginPercent)
        assertNull(result.roiPercent)
        // Дни считаются от даты покупки, пока сделка не продана
        assertEquals(DateUtils.daysBetween(purchase, today), result.daysInTurnover)
    }

    @Test
    fun draftDealHasNoProfitMarginAndRoi() {
        val today = DateUtils.startOfToday()

        val result = SaleMath.calculate(
            purchasePrice = 40_000.0,
            salePrice = null,
            avitoPercent = 5.0,
            deliveryPacking = 0.0,
            otherExpenses = 0.0,
            categoryCosts = 0.0,
            purchaseDate = today,
            saleDate = null,
            status = SaleStatus.DRAFT,
            today = today
        )

        assertFalse(result.isSold)
        assertEquals(0.0, result.profit, 0.001)
        assertNull(result.marginPercent)
        assertNull(result.roiPercent)
    }

    @Test
    fun saleEntityComputesProfitOnlyForSoldStatus() {
        val today = DateUtils.startOfToday()

        val inProgress = Sale(
            title = "iPhone 13",
            purchasePrice = 40_000.0,
            salePrice = 55_000.0,
            avitoPercent = 5.0,
            purchaseDate = today - 2 * day,
            saleDate = today,
            status = SaleStatus.IN_PROGRESS
        )
        assertTrue(inProgress.isInProgress)
        assertFalse(inProgress.isSold)
        assertEquals(0.0, inProgress.profit, 0.001)
        assertEquals(0.0, inProgress.commission, 0.001)

        val sold = inProgress.copy(status = SaleStatus.SOLD)
        assertTrue(sold.isSold)
        assertEquals(2_750.0, sold.commission, 0.001)
        assertEquals(12_250.0, sold.profit, 0.001)
    }

    @Test
    fun lossDealGivesNegativeProfit() {
        val today = DateUtils.startOfToday()

        val result = SaleMath.calculate(
            purchasePrice = 50_000.0,
            salePrice = 45_000.0,
            avitoPercent = 5.0,
            deliveryPacking = 1_000.0,
            otherExpenses = 0.0,
            categoryCosts = 0.0,
            purchaseDate = today - 10 * day,
            saleDate = today,
            status = SaleStatus.SOLD,
            today = today
        )

        assertEquals(-8_250.0, result.profit, 0.001)
        assertTrue(result.roiPercent!! < 0)
    }

    @Test
    fun numericMaskKeepsOnlyDigitsAndOneSeparator() {
        assertEquals("12345", NumberUtils.sanitizeDecimal("12345"))
        assertEquals("12345,67", NumberUtils.sanitizeDecimal("12345,67"))
        assertEquals("12345.67", NumberUtils.sanitizeDecimal("12345.67").replace(',', '.'))
        assertEquals("12345,678", NumberUtils.sanitizeDecimal("12345,67,8"))
        assertEquals("", NumberUtils.sanitizeDecimal("абв"))
        // Минус отбрасывается, само значение остаётся положительным
        assertEquals("500", NumberUtils.sanitizeDecimal("-500"))
    }

    @Test
    fun parsesAmountWithCommaAndDot() {
        assertEquals(1234.56, NumberUtils.parseAmount("1234,56"), 0.001)
        assertEquals(1234.56, NumberUtils.parseAmount("1234.56"), 0.001)
        assertEquals(0.0, NumberUtils.parseAmount("-100"), 0.001)
        assertEquals(0.0, NumberUtils.parseAmount(""), 0.001)
    }
}
